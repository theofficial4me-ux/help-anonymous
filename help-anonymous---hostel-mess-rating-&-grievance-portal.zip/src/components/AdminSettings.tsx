import React, { useState, useEffect } from 'react';
import { User, Key, ShieldCheck, Download, AlertTriangle, Check, Lock } from 'lucide-react';

interface AdminSettingsProps {
  adminToken: string;
  onUsernameChanged?: (newUsername: string) => void;
}

export const AdminSettings: React.FC<AdminSettingsProps> = ({ adminToken, onUsernameChanged }) => {
  const [username, setUsername] = useState('admin.complaint');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [authorizedGoogleEmails, setAuthorizedGoogleEmails] = useState<string[]>([]);

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const fetchProfile = async () => {
    try {
      const res = await fetch('/api/admin/me', {
        headers: { Authorization: `Bearer ${adminToken}` }
      });
      const data = await res.json();
      if (data.username) {
        setUsername(data.username);
        setNewUsername(data.username);
      }
      if (data.authorizedGoogleEmails) {
        setAuthorizedGoogleEmails(data.authorizedGoogleEmails);
      }
    } catch (err) {
      console.error('Error fetching admin profile:', err);
    }
  };

  useEffect(() => {
    fetchProfile();
  }, []);

  const handleChangeCredentials = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!currentPassword) {
      setError('Please provide current administrator password.');
      return;
    }

    if (newPassword && newPassword !== confirmPassword) {
      setError('New passwords do not match.');
      return;
    }

    setIsLoading(true);
    try {
      const res = await fetch('/api/admin/change-credentials', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`
        },
        body: JSON.stringify({
          currentPassword,
          newUsername: newUsername.trim() || undefined,
          newPassword: newPassword.trim() || undefined
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to update credentials');

      setSuccess('Administrator credentials updated securely!');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      if (data.username) {
        setUsername(data.username);
        onUsernameChanged?.(data.username);
      }
    } catch (err: any) {
      setError(err.message || 'Error updating credentials');
    } finally {
      setIsLoading(false);
    }
  };

  const handleBackupExport = () => {
    window.location.href = '/api/admin/backup';
  };

  return (
    <div className="space-y-8 max-w-4xl">
      {/* Change Credentials Card */}
      <div className="rounded-3xl border border-white/10 bg-slate-900/60 backdrop-blur-xl p-6 sm:p-8 space-y-6">
        <div>
          <h3 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
            <Lock className="w-5 h-5 text-sky-400" />
            Administrator Account Credentials
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            Update your admin login username and password. Changes persist in the secure hashed database.
          </p>
        </div>

        {error && (
          <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {success && (
          <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs flex items-center gap-2">
            <Check className="w-4 h-4 shrink-0" />
            <span>{success}</span>
          </div>
        )}

        <form onSubmit={handleChangeCredentials} className="space-y-4 max-w-md">
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Current Username
            </label>
            <input
              type="text"
              disabled
              value={username}
              className="w-full px-4 py-2.5 rounded-xl border border-white/10 bg-slate-800/40 text-slate-400 font-mono text-xs cursor-not-allowed"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              New Username
            </label>
            <input
              type="text"
              value={newUsername}
              onChange={(e) => setNewUsername(e.target.value)}
              placeholder="e.g. chief.warden or mess.chair"
              className="w-full px-4 py-2.5 rounded-xl border border-white/10 bg-slate-800 text-white font-mono text-xs focus:outline-none focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Current Password *
            </label>
            <input
              type="password"
              required
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              placeholder="Verify existing password"
              className="w-full px-4 py-2.5 rounded-xl border border-white/10 bg-slate-800 text-white text-xs focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                New Password (Optional)
              </label>
              <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Min 6 characters"
                className="w-full px-4 py-2.5 rounded-xl border border-white/10 bg-slate-800 text-white text-xs focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Confirm New Password
              </label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Re-enter password"
                className="w-full px-4 py-2.5 rounded-xl border border-white/10 bg-slate-800 text-white text-xs focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={isLoading}
              className="py-2.5 px-6 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold transition-colors cursor-pointer disabled:opacity-50"
            >
              {isLoading ? 'Updating...' : 'Update Admin Credentials'}
            </button>
          </div>
        </form>
      </div>

      {/* Google Login Authorization List */}
      <div className="rounded-3xl border border-white/10 bg-slate-900/60 backdrop-blur-xl p-6 sm:p-8 space-y-4">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            Authorized Google Login Accounts
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            As enforced in Section 4, Google login is restricted strictly to authorized hostel administrators.
          </p>
        </div>

        <div className="space-y-2">
          {authorizedGoogleEmails.map((email, idx) => (
            <div key={idx} className="flex items-center justify-between p-3 rounded-xl bg-slate-800/60 border border-white/5 text-xs font-mono text-slate-300">
              <span>{email}</span>
              <span className="text-[10px] text-emerald-400 font-sans font-semibold">Active Authorized Admin</span>
            </div>
          ))}
        </div>
      </div>

      {/* Full Database Backup & Export */}
      <div className="rounded-3xl border border-white/10 bg-slate-900/60 backdrop-blur-xl p-6 sm:p-8 space-y-4">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Download className="w-5 h-5 text-sky-400" />
            Database Backup &amp; JSON Export
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            Download a complete transactional JSON snapshot of all menu items, ratings, complaints, cook staff, and customization settings.
          </p>
        </div>

        <button
          onClick={handleBackupExport}
          className="px-5 py-2.5 rounded-xl border border-white/10 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer"
        >
          <Download className="w-4 h-4 text-sky-400" />
          <span>Export Complete Database (JSON)</span>
        </button>
      </div>
    </div>
  );
};
