import React, { useState, useEffect } from 'react';
import {
  FileText,
  Download,
  Printer,
  Calendar,
  TrendingUp,
  TrendingDown,
  CheckCircle,
  AlertTriangle,
  Clock,
  Sparkles,
  Bell,
  Mail,
  Send,
  Save,
  Check
} from 'lucide-react';
import { WeeklyReportSummary, ReminderSettings } from '../types';

interface AdminWeeklyReportProps {
  adminToken: string;
}

export const AdminWeeklyReport: React.FC<AdminWeeklyReportProps> = ({ adminToken }) => {
  const [report, setReport] = useState<WeeklyReportSummary | null>(null);
  const [reminderSettings, setReminderSettings] = useState<ReminderSettings>({
    reminderEnabled: true,
    reportDay: 'Monday',
    reminderTime: '09:00',
    emailNotification: 'warden@hostel.edu'
  });
  const [isLoading, setIsLoading] = useState(false);
  const [isSavingReminder, setIsSavingReminder] = useState(false);
  const [reminderSavedToast, setReminderSavedToast] = useState(false);
  const [triggerSimulatedAlert, setTriggerSimulatedAlert] = useState(false);

  const fetchReport = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/admin/reports/weekly', {
        headers: { Authorization: `Bearer ${adminToken}` }
      });
      const data = await res.json();
      setReport(data);
    } catch (err) {
      console.error('Failed to fetch report:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchReminderSettings = async () => {
    try {
      const res = await fetch('/api/settings');
      const data = await res.json();
      if (data.reminderSettings) {
        setReminderSettings(data.reminderSettings);
      }
    } catch (err) {
      console.error('Failed to fetch reminder settings:', err);
    }
  };

  useEffect(() => {
    fetchReport();
    fetchReminderSettings();
  }, []);

  const handleSaveReminders = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingReminder(true);
    try {
      const res = await fetch('/api/admin/reports/reminder-settings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`
        },
        body: JSON.stringify(reminderSettings)
      });
      const data = await res.json();
      if (data.success) {
        setReminderSavedToast(true);
        setTimeout(() => setReminderSavedToast(false), 3000);
      }
    } catch (err) {
      alert('Failed to save reminder preferences');
    } finally {
      setIsSavingReminder(false);
    }
  };

  const handleDownloadCSV = () => {
    window.location.href = '/api/admin/reports/download-csv';
  };

  const handlePrintReport = () => {
    window.print();
  };

  if (isLoading || !report) {
    return (
      <div className="py-20 text-center">
        <div className="w-8 h-8 mx-auto border-2 border-blue-500/30 border-t-blue-500 rounded-full animate-spin" />
        <p className="text-xs text-slate-400 mt-3">Compiling weekly warden report...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Action Header (hidden in print) */}
      <div className="no-print flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-slate-900/80 border border-white/10 backdrop-blur-md">
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-sky-400">Hostel Mess Oversight</span>
          <h3 className="text-xl font-bold text-white tracking-tight">Hostel Mess Weekly Report for Warden</h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Report Window: <strong className="text-slate-200">{report.startDate}</strong> to <strong className="text-slate-200">{report.endDate}</strong>
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleDownloadCSV}
            className="px-3.5 py-2 text-xs font-semibold rounded-xl border border-white/10 bg-slate-800 hover:bg-slate-700 text-white flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4 text-sky-400" />
            <span>Download CSV</span>
          </button>
          <button
            onClick={handlePrintReport}
            className="px-3.5 py-2 text-xs font-semibold rounded-xl bg-blue-600 hover:bg-blue-500 text-white flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>Print / Save PDF</span>
          </button>
        </div>
      </div>

      {/* Printable Report Canvas */}
      <div className="print-page rounded-3xl border border-white/10 bg-slate-900/60 backdrop-blur-xl p-6 sm:p-10 shadow-2xl space-y-8">
        {/* Report Official Banner */}
        <div className="border-b border-white/10 pb-6 flex flex-col sm:flex-row justify-between items-start gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-sky-500/20 text-sky-300">
                {report.reportId}
              </span>
              <span className="text-xs text-slate-400">Hostel Welfare &amp; Dining Board</span>
            </div>
            <h2 className="text-2xl font-bold text-white mt-1">Hostel Mess Quality &amp; Complaint Audit</h2>
            <p className="text-xs text-slate-400">
              Generated automatically on {new Date(report.generatedDate).toLocaleDateString()}
            </p>
          </div>

          <div className="text-right">
            <span className="text-xs text-slate-400">Overall Rating</span>
            <div className="text-3xl font-bold text-white font-mono flex items-center justify-end gap-1.5">
              <span>{report.averageMealRating.toFixed(1)}</span>
              <span className="text-amber-400 text-lg">★</span>
            </div>
            <div className="text-[11px] text-emerald-400 flex items-center justify-end gap-1 mt-0.5">
              <TrendingUp className="w-3 h-3" />
              <span>+{report.weeklyRatingComparison.percentageChange}% vs Prev Week</span>
            </div>
          </div>
        </div>

        {/* 4 Summary Metric Tiles */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="p-4 rounded-2xl bg-slate-800/60 border border-white/5 space-y-1">
            <span className="text-[11px] font-semibold text-slate-400 uppercase">Total Complaints</span>
            <p className="text-2xl font-bold font-mono text-white">{report.totalComplaints}</p>
            <span className="text-[10px] text-slate-500">During last 7 days</span>
          </div>

          <div className="p-4 rounded-2xl bg-slate-800/60 border border-white/5 space-y-1">
            <span className="text-[11px] font-semibold text-emerald-400 uppercase">Resolved (Done)</span>
            <p className="text-2xl font-bold font-mono text-emerald-400">{report.totalResolved}</p>
            <span className="text-[10px] text-slate-500">Action taken by kitchen</span>
          </div>

          <div className="p-4 rounded-2xl bg-slate-800/60 border border-white/5 space-y-1">
            <span className="text-[11px] font-semibold text-amber-400 uppercase">Pending Review</span>
            <p className="text-2xl font-bold font-mono text-amber-400">{report.totalPending}</p>
            <span className="text-[10px] text-slate-500">Needs warden review</span>
          </div>

          <div className="p-4 rounded-2xl bg-slate-800/60 border border-white/5 space-y-1">
            <span className="text-[11px] font-semibold text-blue-400 uppercase">Saved for Committee</span>
            <p className="text-2xl font-bold font-mono text-blue-400">{report.totalSaved}</p>
            <span className="text-[10px] text-slate-500">Flagged for meeting</span>
          </div>
        </div>

        {/* Meal-Wise Ratings Breakdown */}
        <div className="space-y-3">
          <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
            Meal-Wise Student Ratings
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            {Object.entries(report.mealRatings).map(([meal, data]) => (
              <div key={meal} className="p-3.5 rounded-xl bg-slate-800/40 border border-white/5 flex items-center justify-between">
                <div>
                  <span className="text-xs font-semibold text-white">{meal}</span>
                  <div className="text-[11px] text-slate-400">{data.count} submissions</div>
                </div>
                <div className="text-right">
                  <span className="text-sm font-bold font-mono text-amber-400">
                    {data.average > 0 ? data.average.toFixed(1) : 'N/A'} ★
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 2-Column: Most Complained Items & Staff Complaints */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Top Complained Food Items */}
          <div className="p-5 rounded-2xl bg-slate-800/50 border border-white/5 space-y-3">
            <h4 className="text-xs font-semibold text-rose-300 uppercase tracking-wider flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5" />
              Most Complained-About Food Items
            </h4>
            <div className="space-y-2">
              {report.topComplainedItems.length === 0 ? (
                <p className="text-xs text-slate-500">No recurring food complaints recorded.</p>
              ) : (
                report.topComplainedItems.map((item, idx) => (
                  <div key={idx} className="flex items-center justify-between text-xs p-2 rounded-lg bg-slate-900/60">
                    <span className="font-medium text-slate-200">{item.item}</span>
                    <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-rose-500/20 text-rose-300 font-bold">
                      {item.count} {item.count === 1 ? 'report' : 'reports'} ({item.category})
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Cook Staff-Wise Grievance Stats */}
          <div className="p-5 rounded-2xl bg-slate-800/50 border border-white/5 space-y-3">
            <h4 className="text-xs font-semibold text-sky-300 uppercase tracking-wider flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5" />
              Cook Staff-Wise Complaint Distribution
            </h4>
            <div className="space-y-2">
              {report.staffComplaints.length === 0 ? (
                <p className="text-xs text-slate-500">No staff-tagged complaints recorded.</p>
              ) : (
                report.staffComplaints.map((s, idx) => (
                  <div key={idx} className="flex items-center justify-between text-xs p-2 rounded-lg bg-slate-900/60">
                    <span className="font-medium text-slate-200">{s.staff}</span>
                    <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-sky-500/20 text-sky-300 font-bold">
                      {s.count} {s.count === 1 ? 'complaint' : 'complaints'}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Student Suggestions Section */}
        <div className="p-5 rounded-2xl bg-slate-800/50 border border-white/5 space-y-3">
          <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
            Key Student Suggestions Submitted Anonymously
          </h4>
          <div className="space-y-2">
            {report.recentSuggestions.length === 0 ? (
              <p className="text-xs text-slate-500">No recent suggestions submitted.</p>
            ) : (
              report.recentSuggestions.map((sug, idx) => (
                <div key={idx} className="p-3 rounded-xl bg-slate-900/70 border border-white/5 text-xs text-slate-300">
                  "{sug}"
                </div>
              ))
            )}
          </div>
        </div>

        {/* Improvement Recommendations for Warden & Mess Committee */}
        <div className="p-6 rounded-2xl bg-gradient-to-br from-blue-950/40 to-indigo-950/40 border border-blue-500/20 space-y-3">
          <h4 className="text-xs font-semibold text-sky-300 uppercase tracking-wider flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-sky-400" />
            Actionable Recommendations for Warden &amp; Mess Committee
          </h4>
          <ul className="space-y-2 text-xs text-slate-300">
            {report.recommendations.map((rec, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <CheckCircle className="w-3.5 h-3.5 text-sky-400 mt-0.5 shrink-0" />
                <span className="leading-relaxed">{rec}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* WEEKLY REMINDER SETTINGS (as requested in Section 8) */}
      <div className="no-print rounded-3xl border border-white/10 bg-slate-900/70 backdrop-blur-xl p-6 sm:p-8 space-y-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
            <Bell className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-base font-bold text-white">Scheduled Weekly Report Reminder Settings</h4>
            <p className="text-xs text-slate-400">
              Automated reminder sent to warden and mess committee to review weekly feedback.
            </p>
          </div>
        </div>

        {/* Reminder Preview Box */}
        <div className="p-4 rounded-2xl bg-slate-800/80 border border-white/10 space-y-1">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
            Automated Alert Preview Message:
          </span>
          <p className="text-xs font-mono text-amber-300">
            "Your weekly Hostel Mess Feedback Report is ready. Please review the latest student feedback and pending complaints."
          </p>
        </div>

        <form onSubmit={handleSaveReminders} className="grid grid-cols-1 sm:grid-cols-4 gap-4 items-end">
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Report Day
            </label>
            <select
              value={reminderSettings.reportDay}
              onChange={(e) => setReminderSettings({ ...reminderSettings, reportDay: e.target.value })}
              className="w-full px-3 py-2 text-xs rounded-xl border border-white/10 bg-slate-800 text-white focus:outline-none focus:border-blue-500"
            >
              {['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'].map((day) => (
                <option key={day} value={day}>
                  {day}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Reminder Time
            </label>
            <input
              type="time"
              value={reminderSettings.reminderTime}
              onChange={(e) => setReminderSettings({ ...reminderSettings, reminderTime: e.target.value })}
              className="w-full px-3 py-2 text-xs rounded-xl border border-white/10 bg-slate-800 text-white focus:outline-none focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Warden Email Notification
            </label>
            <input
              type="email"
              value={reminderSettings.emailNotification}
              onChange={(e) => setReminderSettings({ ...reminderSettings, emailNotification: e.target.value })}
              placeholder="warden@hostel.edu"
              className="w-full px-3 py-2 text-xs rounded-xl border border-white/10 bg-slate-800 text-white focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="flex items-center gap-3">
            <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-300">
              <input
                type="checkbox"
                checked={reminderSettings.reminderEnabled}
                onChange={(e) => setReminderSettings({ ...reminderSettings, reminderEnabled: e.target.checked })}
                className="rounded border-white/20 text-blue-600 focus:ring-0"
              />
              <span>Enable Automation</span>
            </label>

            <button
              type="submit"
              disabled={isSavingReminder}
              className="py-2 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              {isSavingReminder ? (
                <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : reminderSavedToast ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-300" />
                  <span>Saved!</span>
                </>
              ) : (
                <>
                  <Save className="w-3.5 h-3.5" />
                  <span>Save Settings</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
