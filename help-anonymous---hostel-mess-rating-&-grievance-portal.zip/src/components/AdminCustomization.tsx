import React, { useState } from 'react';
import {
  Palette,
  Type,
  Layout,
  Sparkles,
  Save,
  RotateCcw,
  Check,
  Eye,
  Sliders
} from 'lucide-react';
import { WebsiteSettings, ThemeName } from '../types';
import { THEME_DEFINITIONS } from '../themeConfig';

interface AdminCustomizationProps {
  settings: WebsiteSettings;
  adminToken: string;
  onSettingsUpdated: (newSettings: WebsiteSettings) => void;
}

export const AdminCustomization: React.FC<AdminCustomizationProps> = ({
  settings,
  adminToken,
  onSettingsUpdated
}) => {
  const [formSettings, setFormSettings] = useState<WebsiteSettings>(settings);
  const [activeTab, setActiveTab] = useState<'themes' | 'branding' | 'typography' | 'colors' | 'layout'>('themes');
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Apply a theme preset
  const handleApplyTheme = async (themeKey: ThemeName) => {
    const themeDef = THEME_DEFINITIONS[themeKey];
    if (!themeDef) return;

    const updated: WebsiteSettings = {
      ...formSettings,
      activeTheme: themeKey,
      typography: {
        ...formSettings.typography,
        fontFamily: themeDef.fontFamily,
        headingFont: themeDef.headingFont
      },
      colors: {
        ...formSettings.colors,
        primary: themeDef.primaryColor,
        accent: themeDef.accentColor,
        background: themeDef.backgroundColor,
        cardBackground: themeDef.cardBackground,
        text: themeDef.textColor
      },
      layout: {
        ...formSettings.layout,
        borderRadius: themeDef.borderRadius
      }
    };

    setFormSettings(updated);
    await saveSettingsToServer(updated);
  };

  const saveSettingsToServer = async (payload: WebsiteSettings) => {
    setIsSaving(true);
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`
        },
        body: JSON.stringify({ settings: payload })
      });
      const data = await res.json();
      if (data.settings) {
        onSettingsUpdated(data.settings);
        setSaveSuccess(true);
        setTimeout(() => setSaveSuccess(false), 3000);
      }
    } catch (err) {
      alert('Failed to save settings to server');
    } finally {
      setIsSaving(false);
    }
  };

  const handleResetToDefault = async () => {
    if (!window.confirm('Reset all website branding, fonts and themes to Liquid Glass default?')) return;
    setIsSaving(true);
    try {
      const res = await fetch('/api/admin/settings/reset', {
        method: 'POST',
        headers: { Authorization: `Bearer ${adminToken}` }
      });
      const data = await res.json();
      if (data.settings) {
        setFormSettings(data.settings);
        onSettingsUpdated(data.settings);
        setSaveSuccess(true);
        setTimeout(() => setSaveSuccess(false), 3000);
      }
    } catch (err) {
      alert('Failed to reset settings');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Sub-navigation tabs */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-2 rounded-2xl bg-slate-900/80 border border-white/10 backdrop-blur-md">
        <div className="flex flex-wrap items-center gap-1.5">
          {[
            { id: 'themes', label: '10 Website Themes', icon: Sparkles },
            { id: 'branding', label: 'Branding & Content', icon: Layout },
            { id: 'typography', label: 'Typography', icon: Type },
            { id: 'colors', label: 'Color Palette', icon: Palette },
            { id: 'layout', label: 'Layout & Shapes', icon: Sliders }
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
                  activeTab === tab.id
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleResetToDefault}
            className="px-3 py-1.5 text-xs font-medium rounded-xl border border-white/10 text-slate-400 hover:text-white hover:bg-white/5 flex items-center gap-1.5 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset to Default</span>
          </button>
          <button
            onClick={() => saveSettingsToServer(formSettings)}
            disabled={isSaving}
            className="px-4 py-1.5 text-xs font-semibold rounded-xl bg-blue-600 hover:bg-blue-500 text-white flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            {isSaving ? (
              <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : saveSuccess ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-300" />
                <span>Applied Globally!</span>
              </>
            ) : (
              <>
                <Save className="w-3.5 h-3.5" />
                <span>Save Custom Theme</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* 1. THEMES TAB (All 10 Themes with Live Previews) */}
      {activeTab === 'themes' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-slate-900/60 border border-white/10">
            <h4 className="text-sm font-bold text-white">Select One of 10 Complete Website Themes</h4>
            <p className="text-xs text-slate-400 mt-0.5">
              Each theme customizes background gradients, cards, borders, typography, and button dynamics instantly across the entire website.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {Object.values(THEME_DEFINITIONS).map((t) => {
              const isSelected = formSettings.activeTheme === t.id;
              return (
                <div
                  key={t.id}
                  className={`rounded-2xl border p-5 flex flex-col justify-between transition-all duration-300 ${
                    isSelected
                      ? 'border-sky-400 ring-2 ring-sky-500/20 bg-slate-900/90 shadow-xl'
                      : 'border-white/10 bg-slate-900/60 hover:border-white/20'
                  }`}
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="text-base font-bold text-white">{t.name}</h4>
                        <span className="text-[11px] text-sky-400 font-medium">{t.tagline}</span>
                      </div>
                      {isSelected && (
                        <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-sky-500/20 text-sky-300 border border-sky-500/30">
                          Active Theme
                        </span>
                      )}
                    </div>

                    <p className="text-xs text-slate-400 leading-relaxed">{t.description}</p>

                    {/* Live miniature visual preview box for this theme */}
                    <div
                      className="p-3.5 rounded-xl border space-y-2"
                      style={{
                        backgroundColor: t.backgroundColor,
                        color: t.textColor,
                        borderColor: t.accentColor,
                        fontFamily: t.fontFamily
                      }}
                    >
                      <div className="flex items-center justify-between text-xs font-semibold">
                        <span>{formSettings.websiteName}</span>
                        <div
                          className="w-2.5 h-2.5 rounded-full"
                          style={{ backgroundColor: t.primaryColor }}
                        />
                      </div>
                      <div
                        className="p-2.5 rounded-lg text-xs"
                        style={{
                          backgroundColor: t.cardBackground,
                          boxShadow: t.shadowStyle,
                          border: t.borderStyle
                        }}
                      >
                        <div className="text-[11px] opacity-80">Today's Dinner Rating</div>
                        <div className="text-xs font-bold mt-0.5" style={{ color: t.primaryColor }}>
                          ★ 4.8 / 5.0 (148 votes)
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          className="px-2.5 py-1 text-[10px] font-semibold text-white rounded"
                          style={{
                            backgroundColor: t.primaryColor,
                            borderRadius: t.borderRadius
                          }}
                        >
                          Submit Feedback
                        </button>
                        <span className="text-[10px] opacity-70">Font: {t.fontFamily}</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 mt-4 border-t border-white/5 flex items-center justify-between">
                    <div className="flex items-center gap-1.5 text-xs text-slate-400">
                      <span className="w-3 h-3 rounded-full" style={{ backgroundColor: t.primaryColor }} />
                      <span className="w-3 h-3 rounded-full" style={{ backgroundColor: t.accentColor }} />
                    </div>
                    <button
                      onClick={() => handleApplyTheme(t.id)}
                      disabled={isSelected || isSaving}
                      className={`px-4 py-1.5 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-white/10 text-slate-400 cursor-default'
                          : 'bg-blue-600 hover:bg-blue-500 text-white'
                      }`}
                    >
                      {isSelected ? 'Currently Applied' : 'Apply Theme'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 2. BRANDING TAB */}
      {activeTab === 'branding' && (
        <div className="rounded-3xl border border-white/10 bg-slate-900/60 backdrop-blur-xl p-6 sm:p-8 space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Website Name
              </label>
              <input
                type="text"
                value={formSettings.websiteName}
                onChange={(e) => setFormSettings({ ...formSettings, websiteName: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl border border-white/10 bg-slate-800 text-white text-sm focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Tagline
              </label>
              <input
                type="text"
                value={formSettings.tagline}
                onChange={(e) => setFormSettings({ ...formSettings, tagline: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl border border-white/10 bg-slate-800 text-white text-sm focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Homepage Hero Heading
              </label>
              <input
                type="text"
                value={formSettings.heroHeading}
                onChange={(e) => setFormSettings({ ...formSettings, heroHeading: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl border border-white/10 bg-slate-800 text-white text-sm focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Welcome Message / Introduction
              </label>
              <textarea
                rows={3}
                value={formSettings.welcomeMessage}
                onChange={(e) => setFormSettings({ ...formSettings, welcomeMessage: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl border border-white/10 bg-slate-800 text-white text-sm focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Footer Copyright Text
              </label>
              <input
                type="text"
                value={formSettings.footerText}
                onChange={(e) => setFormSettings({ ...formSettings, footerText: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl border border-white/10 bg-slate-800 text-white text-sm focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>
        </div>
      )}

      {/* 3. TYPOGRAPHY TAB */}
      {activeTab === 'typography' && (
        <div className="rounded-3xl border border-white/10 bg-slate-900/60 backdrop-blur-xl p-6 sm:p-8 space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Body Font Family
              </label>
              <select
                value={formSettings.typography.fontFamily}
                onChange={(e) =>
                  setFormSettings({
                    ...formSettings,
                    typography: { ...formSettings.typography, fontFamily: e.target.value }
                  })
                }
                className="w-full px-3 py-2.5 rounded-xl border border-white/10 bg-slate-800 text-white text-sm focus:outline-none focus:border-blue-500"
              >
                <option value="Plus Jakarta Sans">Plus Jakarta Sans</option>
                <option value="Outfit">Outfit</option>
                <option value="DM Sans">DM Sans</option>
                <option value="Space Grotesk">Space Grotesk</option>
                <option value="JetBrains Mono">JetBrains Mono</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Heading Font Family
              </label>
              <select
                value={formSettings.typography.headingFont}
                onChange={(e) =>
                  setFormSettings({
                    ...formSettings,
                    typography: { ...formSettings.typography, headingFont: e.target.value }
                  })
                }
                className="w-full px-3 py-2.5 rounded-xl border border-white/10 bg-slate-800 text-white text-sm focus:outline-none focus:border-blue-500"
              >
                <option value="Outfit">Outfit</option>
                <option value="Plus Jakarta Sans">Plus Jakarta Sans</option>
                <option value="Space Grotesk">Space Grotesk</option>
                <option value="DM Sans">DM Sans</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Base Font Size
              </label>
              <select
                value={formSettings.typography.fontSize}
                onChange={(e) =>
                  setFormSettings({
                    ...formSettings,
                    typography: { ...formSettings.typography, fontSize: e.target.value as any }
                  })
                }
                className="w-full px-3 py-2.5 rounded-xl border border-white/10 bg-slate-800 text-white text-sm focus:outline-none focus:border-blue-500"
              >
                <option value="small">Small (Compact 14px)</option>
                <option value="medium">Medium (Standard 16px)</option>
                <option value="large">Large (High Legibility 18px)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Line Height
              </label>
              <select
                value={formSettings.typography.lineHeight}
                onChange={(e) =>
                  setFormSettings({
                    ...formSettings,
                    typography: { ...formSettings.typography, lineHeight: e.target.value as any }
                  })
                }
                className="w-full px-3 py-2.5 rounded-xl border border-white/10 bg-slate-800 text-white text-sm focus:outline-none focus:border-blue-500"
              >
                <option value="tight">Tight</option>
                <option value="normal">Normal</option>
                <option value="relaxed">Relaxed</option>
              </select>
            </div>
          </div>
        </div>
      )}

      {/* 4. COLORS TAB */}
      {activeTab === 'colors' && (
        <div className="rounded-3xl border border-white/10 bg-slate-900/60 backdrop-blur-xl p-6 sm:p-8 space-y-5">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { label: 'Primary Color', key: 'primary' },
              { label: 'Accent Color', key: 'accent' },
              { label: 'Button Color', key: 'button' },
              { label: 'Secondary Color', key: 'secondary' }
            ].map((col) => (
              <div key={col.key} className="p-3.5 rounded-2xl bg-slate-800/60 border border-white/10 space-y-2">
                <label className="block text-xs font-semibold text-slate-300">{col.label}</label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={(formSettings.colors as any)[col.key] || '#3b82f6'}
                    onChange={(e) =>
                      setFormSettings({
                        ...formSettings,
                        colors: { ...formSettings.colors, [col.key]: e.target.value }
                      })
                    }
                    className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                  />
                  <input
                    type="text"
                    value={(formSettings.colors as any)[col.key] || '#3b82f6'}
                    onChange={(e) =>
                      setFormSettings({
                        ...formSettings,
                        colors: { ...formSettings.colors, [col.key]: e.target.value }
                      })
                    }
                    className="w-full px-2 py-1 text-xs font-mono rounded border border-white/10 bg-slate-900 text-white"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 5. LAYOUT TAB */}
      {activeTab === 'layout' && (
        <div className="rounded-3xl border border-white/10 bg-slate-900/60 backdrop-blur-xl p-6 sm:p-8 space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Header Style
              </label>
              <select
                value={formSettings.layout.headerStyle}
                onChange={(e) =>
                  setFormSettings({
                    ...formSettings,
                    layout: { ...formSettings.layout, headerStyle: e.target.value as any }
                  })
                }
                className="w-full px-3 py-2.5 rounded-xl border border-white/10 bg-slate-800 text-white text-sm focus:outline-none focus:border-blue-500"
              >
                <option value="glass">Frosted Glass</option>
                <option value="solid">Solid Background</option>
                <option value="minimal">Minimal Flat</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Button Shape
              </label>
              <select
                value={formSettings.layout.buttonShape}
                onChange={(e) =>
                  setFormSettings({
                    ...formSettings,
                    layout: { ...formSettings.layout, buttonShape: e.target.value as any }
                  })
                }
                className="w-full px-3 py-2.5 rounded-xl border border-white/10 bg-slate-800 text-white text-sm focus:outline-none focus:border-blue-500"
              >
                <option value="rounded-xl">Rounded-XL (Modern)</option>
                <option value="pill">Pill (Fully Rounded)</option>
                <option value="sharp">Sharp (0px Neo-Brutal)</option>
                <option value="rounded">Standard Rounded</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Card Border Radius
              </label>
              <input
                type="text"
                value={formSettings.layout.borderRadius}
                onChange={(e) =>
                  setFormSettings({
                    ...formSettings,
                    layout: { ...formSettings.layout, borderRadius: e.target.value }
                  })
                }
                placeholder="e.g. 1.25rem or 16px"
                className="w-full px-4 py-2.5 rounded-xl border border-white/10 bg-slate-800 text-white text-sm focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
