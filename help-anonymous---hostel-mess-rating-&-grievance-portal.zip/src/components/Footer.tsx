import React from 'react';
import { ShieldCheck, Lock, Heart, Award } from 'lucide-react';
import { WebsiteSettings } from '../types';

interface FooterProps {
  settings: WebsiteSettings;
  onSelectTab: (tab: string) => void;
  onOpenAdminLogin: () => void;
}

export const Footer: React.FC<FooterProps> = ({ settings, onSelectTab, onOpenAdminLogin }) => {
  return (
    <footer className="border-t border-white/10 bg-slate-950/60 backdrop-blur-md text-slate-400 py-12 px-4 sm:px-6 lg:px-8 mt-20 transition-colors">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8">
        <div className="md:col-span-2 space-y-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white"
              style={{ backgroundColor: settings.colors.primary }}
            >
              <ShieldCheck className="w-5 h-5" />
            </div>
            <span className="text-lg font-bold text-white tracking-tight">
              {settings.websiteName || 'HELP ANONYMOUS'}
            </span>
          </div>
          <p className="text-sm text-slate-400 max-w-md">
            {settings.tagline || 'Your Voice. Your Privacy. Better Hostel Life.'}
          </p>
          <p className="text-xs text-slate-500 pt-1 leading-relaxed max-w-lg">
            Empowering residents to voice honest feedback on meal hygiene, food quality, and mess staff behaviour with zero fear of backlash or personal exposure.
          </p>
        </div>

        <div>
          <h4 className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-3">Quick Navigation</h4>
          <ul className="space-y-2 text-sm">
            <li>
              <button onClick={() => onSelectTab('home')} className="hover:text-white transition-colors cursor-pointer">
                Student Home
              </button>
            </li>
            <li>
              <button onClick={() => onSelectTab('menu')} className="hover:text-white transition-colors cursor-pointer">
                Today's Mess Menu &amp; Ratings
              </button>
            </li>
            <li>
              <button onClick={() => onSelectTab('feedback')} className="hover:text-white transition-colors cursor-pointer">
                Submit Anonymous Complaint
              </button>
            </li>
            <li>
              <button onClick={() => onSelectTab('tracker')} className="hover:text-white transition-colors cursor-pointer">
                Live Grievance Tracker
              </button>
            </li>
            <li>
              <button onClick={() => onSelectTab('about')} className="hover:text-white transition-colors cursor-pointer">
                Student Privacy Guarantee
              </button>
            </li>
          </ul>
        </div>

        <div>
          <h4 className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-3">Hostel Administration</h4>
          <ul className="space-y-2 text-sm">
            <li>
              <button onClick={onOpenAdminLogin} className="flex items-center gap-1.5 hover:text-white transition-colors cursor-pointer">
                <Lock className="w-3.5 h-3.5 text-slate-400" />
                <span>Warden &amp; Committee Login</span>
              </button>
            </li>
            <li className="pt-2 text-xs text-emerald-400 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block"></span>
              <span>100% Student Data Anonymity Enforced</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="max-w-7xl mx-auto pt-8 mt-8 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
        <p>{settings.footerText || '© 2026 HELP ANONYMOUS. Built for Student Welfare, Mess Committees & Hostel Wardens.'}</p>
        <div className="flex items-center gap-4">
          <span>Active Theme: <strong className="text-slate-300 capitalize">{settings.activeTheme}</strong></span>
          <span>·</span>
          <span>End-to-End Privacy</span>
        </div>
      </div>
    </footer>
  );
};
