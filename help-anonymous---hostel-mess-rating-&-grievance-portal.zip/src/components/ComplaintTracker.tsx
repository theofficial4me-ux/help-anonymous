import React, { useState, useEffect } from 'react';
import { Search, Eye, Clock, CheckCircle2, AlertCircle, Bookmark, Archive, ShieldCheck, Bell } from 'lucide-react';
import { ComplaintStatus } from '../types';

interface ComplaintTrackerProps {
  initialSearchId?: string;
  onNavigateFeedback: () => void;
}

export const ComplaintTracker: React.FC<ComplaintTrackerProps> = ({
  initialSearchId,
  onNavigateFeedback
}) => {
  const [searchId, setSearchId] = useState(initialSearchId || '');
  const [complaint, setComplaint] = useState<any | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const fetchStatus = async (idToSearch: string) => {
    if (!idToSearch.trim()) return;
    setError('');
    setIsLoading(true);
    try {
      const res = await fetch(`/api/complaints/track/${encodeURIComponent(idToSearch.trim())}`);
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Complaint not found. Verify your Complaint ID.');
      }
      setComplaint(data);
    } catch (err: any) {
      setComplaint(null);
      setError(err.message || 'Unable to track complaint.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (initialSearchId) {
      setSearchId(initialSearchId);
      fetchStatus(initialSearchId);
    }
  }, [initialSearchId]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchStatus(searchId);
  };

  const getStatusBadge = (status: ComplaintStatus) => {
    switch (status) {
      case 'done':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Done / Resolved
          </span>
        );
      case 'pending':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/20 text-amber-400 border border-amber-500/30">
            <Clock className="w-3.5 h-3.5" />
            Pending Review
          </span>
        );
      case 'saved':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-500/20 text-blue-400 border border-blue-500/30">
            <Bookmark className="w-3.5 h-3.5" />
            Saved for Meeting
          </span>
        );
      case 'ignored':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-slate-500/20 text-slate-400 border border-slate-500/30">
            <AlertCircle className="w-3.5 h-3.5" />
            Ignored / Archived
          </span>
        );
      case 'trash':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-rose-500/20 text-rose-400 border border-rose-500/30">
            <Archive className="w-3.5 h-3.5" />
            Trash
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <section className="py-12 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="text-center mb-10 space-y-3">
        <span className="text-xs font-semibold uppercase tracking-wider text-sky-400">
          Anonymous Grievance Status
        </span>
        <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
          Track Your Anonymous Complaint
        </h2>
        <p className="text-sm text-slate-400 max-w-lg mx-auto">
          Enter the Complaint ID you received upon submitting your feedback. You will see whether the warden has opened and read it.
        </p>
      </div>

      {/* Search Input Box */}
      <div className="rounded-3xl border border-white/10 bg-slate-900/70 backdrop-blur-xl p-6 sm:p-8 shadow-2xl mb-8">
        <form onSubmit={handleSearchSubmit} className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-5 h-5 text-slate-400 absolute left-4 top-3.5" />
            <input
              type="text"
              value={searchId}
              onChange={(e) => setSearchId(e.target.value)}
              placeholder="Enter Complaint ID (e.g. CMP-7041 or CMP-6912)"
              className="w-full pl-12 pr-4 py-3 rounded-2xl border border-white/10 bg-slate-800/80 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-sky-500 font-mono"
            />
          </div>
          <button
            type="submit"
            disabled={isLoading || !searchId.trim()}
            className="py-3 px-6 rounded-2xl bg-sky-600 hover:bg-sky-500 text-white font-semibold text-sm transition-colors cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50 shrink-0"
          >
            {isLoading ? (
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <span>Track Status</span>
            )}
          </button>
        </form>

        {error && (
          <div className="mt-4 p-3.5 rounded-xl border border-rose-500/20 bg-rose-500/10 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {/* Complaint Result Card */}
      {complaint && (
        <div className="rounded-3xl border border-white/10 bg-slate-900/80 backdrop-blur-xl p-6 sm:p-8 shadow-2xl space-y-6 animate-fade-in">
          {/* Silent Open Notice Banner */}
          {complaint.isOpened ? (
            <div className="p-4 rounded-2xl border border-emerald-500/30 bg-emerald-500/10 text-emerald-300 flex items-start gap-3">
              <Eye className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5 animate-pulse" />
              <div>
                <strong className="text-white block font-semibold text-sm">
                  Your complaint has been opened.
                </strong>
                <p className="text-xs text-emerald-200/90 mt-0.5">
                  Hostel administration reviewed this grievance on{' '}
                  <span className="font-mono text-white">
                    {new Date(complaint.firstOpenedAt || complaint.updatedAt).toLocaleString()}
                  </span>
                  .
                </p>
              </div>
            </div>
          ) : (
            <div className="p-4 rounded-2xl border border-amber-500/30 bg-amber-500/10 text-amber-300 flex items-start gap-3">
              <Clock className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-white block font-semibold text-sm">
                  In Warden Review Queue
                </strong>
                <p className="text-xs text-amber-200/90 mt-0.5">
                  Your complaint has been logged and is awaiting the warden's inspection.
                </p>
              </div>
            </div>
          )}

          {/* Details Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div className="p-4 rounded-2xl bg-slate-800/60 border border-white/5 space-y-1">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                Complaint ID
              </span>
              <p className="text-lg font-mono font-bold text-white">{complaint.id}</p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-800/60 border border-white/5 space-y-1">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                Current Status
              </span>
              <div>{getStatusBadge(complaint.status)}</div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-800/60 border border-white/5 space-y-1">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                Food Item &amp; Meal
              </span>
              <p className="text-sm font-semibold text-white">
                {complaint.item} <span className="text-slate-400 font-normal">({complaint.category})</span>
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-800/60 border border-white/5 space-y-1">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                Submission Date
              </span>
              <p className="text-xs font-mono text-slate-300">
                {new Date(complaint.createdAt).toLocaleString()}
              </p>
            </div>
          </div>

          <div className="pt-4 border-t border-white/10 flex items-center justify-between text-xs text-slate-400">
            <span className="flex items-center gap-1.5 text-sky-400">
              <ShieldCheck className="w-4 h-4" />
              Student identity encrypted &amp; hidden from hostel staff
            </span>
            <button
              onClick={onNavigateFeedback}
              className="text-xs text-sky-400 hover:text-sky-300 underline underline-offset-4 cursor-pointer"
            >
              Submit Another Complaint
            </button>
          </div>
        </div>
      )}
    </section>
  );
};
