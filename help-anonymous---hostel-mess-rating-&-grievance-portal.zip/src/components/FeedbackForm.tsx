import React, { useState, useRef } from 'react';
import {
  ShieldAlert,
  Upload,
  X,
  CheckCircle,
  Copy,
  ExternalLink,
  MessageSquare,
  AlertTriangle,
  UserCheck,
  Send,
  Sparkles
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { CookStaff, MealCategory, CookReplyChoice } from '../types';

interface FeedbackFormProps {
  staffList: CookStaff[];
  initialCategory?: MealCategory;
  onTrackComplaint: (id: string) => void;
}

export const FeedbackForm: React.FC<FeedbackFormProps> = ({
  staffList,
  initialCategory,
  onTrackComplaint
}) => {
  const [item, setItem] = useState('');
  const [category, setCategory] = useState<MealCategory>(initialCategory || 'Lunch');
  const [cookStaff, setCookStaff] = useState('');
  const [customCookStaff, setCustomCookStaff] = useState('');
  const [photoUrl, setPhotoUrl] = useState('');
  const [photoPreview, setPhotoPreview] = useState('');
  const [toldCook, setToldCook] = useState<'yes' | 'no' | null>(null);
  const [cookReply, setCookReply] = useState<CookReplyChoice | ''>('');
  const [customReply, setCustomReply] = useState('');
  const [whyNotTold, setWhyNotTold] = useState('');
  const [suggestion, setSuggestion] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [successData, setSuccessData] = useState<{
    complaintId: string;
    trackingToken: string;
    message: string;
  } | null>(null);
  const [copied, setCopied] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Handle Photo upload with preview (JPG, JPEG, PNG, WEBP)
  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    if (!validTypes.includes(file.type)) {
      setError('Supported image formats: JPG, JPEG, PNG, and WEBP only.');
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      setError('Image file is too large. Maximum size is 10MB.');
      return;
    }

    setError('');
    const reader = new FileReader();
    reader.onload = (uploadEvent) => {
      const result = uploadEvent.target?.result as string;
      setPhotoPreview(result);
      setPhotoUrl(result);
    };
    reader.readAsDataURL(file);
  };

  const removePhoto = () => {
    setPhotoPreview('');
    setPhotoUrl('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Submit Feedback handler
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!item.trim()) {
      setError('Please provide the complaint food item name.');
      return;
    }

    if (toldCook === null) {
      setError('Please specify whether you told the cook or not.');
      return;
    }

    if (toldCook === 'yes' && !cookReply) {
      setError('Please select how the cook replied to you.');
      return;
    }

    const effectiveCookStaff =
      cookStaff === 'Other' ? (customCookStaff.trim() || 'Other Cook') : cookStaff || 'Unassigned / General Staff';

    try {
      setIsSubmitting(true);
      const res = await fetch('/api/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          item: item.trim(),
          category,
          cookStaff: effectiveCookStaff,
          photoUrl,
          toldCook,
          cookReply: toldCook === 'yes' ? cookReply : undefined,
          customReply: toldCook === 'yes' && cookReply === 'Other' ? customReply.trim() : undefined,
          whyNotTold: toldCook === 'no' ? whyNotTold.trim() : undefined,
          suggestion: suggestion.trim()
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to submit feedback');
      }

      // Fire confetti celebration
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 }
        });
      } catch (confettiErr) {
        // ignore
      }

      setSuccessData({
        complaintId: data.complaintId,
        trackingToken: data.trackingToken,
        message: data.message || 'Your feedback is very valuable to us. Thank you for your feedback!'
      });

      // Reset form fields
      setItem('');
      setCategory('Lunch');
      setCookStaff('');
      setCustomCookStaff('');
      removePhoto();
      setToldCook(null);
      setCookReply('');
      setCustomReply('');
      setWhyNotTold('');
      setSuggestion('');
    } catch (err: any) {
      setError(err.message || 'Error submitting feedback. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const copyComplaintId = (id: string) => {
    navigator.clipboard.writeText(id);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <section className="py-12 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Privacy Banner */}
      <div className="mb-8 p-4 rounded-2xl border border-sky-500/20 bg-sky-950/30 backdrop-blur-md flex items-start gap-3">
        <ShieldAlert className="w-5 h-5 text-sky-400 shrink-0 mt-0.5" />
        <div className="text-xs text-sky-200 leading-relaxed">
          <strong className="text-white block font-semibold mb-0.5">100% Anonymous &amp; Private Submission</strong>
          No student names, roll numbers, room numbers, emails or IP addresses are collected or shown to wardens. Your feedback is tracked purely via an anonymous complaint token.
        </div>
      </div>

      {/* Main Card */}
      <div className="rounded-3xl border border-white/10 bg-slate-900/70 backdrop-blur-xl p-6 sm:p-10 shadow-2xl">
        <div className="mb-8">
          <span className="text-xs font-semibold uppercase tracking-wider text-sky-400">Hostel Mess Quality Grievance</span>
          <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight mt-1">
            Anonymous Feedback &amp; Complaint Form
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Fill in the details below. Our hostel mess committee and warden inspect every valid complaint.
          </p>
        </div>

        {error && (
          <div className="mb-6 p-4 rounded-xl border border-rose-500/20 bg-rose-500/10 text-rose-300 text-sm flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* 1. Meal Category & Complaint Item Name */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Meal Category *
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as MealCategory)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-white/10 bg-slate-800/80 text-white text-sm focus:outline-none focus:border-sky-500 transition-colors"
              >
                <option value="Breakfast">Breakfast</option>
                <option value="Lunch">Lunch</option>
                <option value="Snacks">Snacks</option>
                <option value="Dinner">Dinner</option>
              </select>
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Complaint Item Name *
              </label>
              <input
                type="text"
                required
                value={item}
                onChange={(e) => setItem(e.target.value)}
                placeholder="e.g. Burnt Rotis, Watery Dal, Raw Rice, Stale Sambar"
                className="w-full px-4 py-2.5 rounded-xl border border-white/10 bg-slate-800/80 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-sky-500 transition-colors"
              />
            </div>
          </div>

          {/* 2. Cook Staff Name */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Cook Staff Name / Serving Counter (Optional)
            </label>
            {staffList.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <select
                  value={cookStaff}
                  onChange={(e) => setCookStaff(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-white/10 bg-slate-800/80 text-white text-sm focus:outline-none focus:border-sky-500 transition-colors"
                >
                  <option value="">-- Select Cook Staff (Optional) --</option>
                  {staffList.map((staff) => (
                    <option key={staff.id} value={staff.name}>
                      {staff.name} ({staff.role})
                    </option>
                  ))}
                  <option value="Other">Other (Type Name / Counter)</option>
                </select>

                {cookStaff === 'Other' && (
                  <input
                    type="text"
                    value={customCookStaff}
                    onChange={(e) => setCustomCookStaff(e.target.value)}
                    placeholder="Enter cook name or counter (e.g. Roti Maker / Curry Desk)"
                    className="w-full px-4 py-2.5 rounded-xl border border-white/10 bg-slate-800/80 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-sky-500 transition-colors"
                  />
                )}
              </div>
            ) : (
              <div>
                <input
                  type="text"
                  value={customCookStaff}
                  onChange={(e) => {
                    setCustomCookStaff(e.target.value);
                    setCookStaff('Other');
                  }}
                  placeholder="Enter cook name, counter, or shift (e.g. Roti Cook / Curry Desk)"
                  className="w-full px-4 py-2.5 rounded-xl border border-white/10 bg-slate-800/80 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-sky-500 transition-colors"
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  Optional: If known, specify the cook's name or kitchen station.
                </p>
              </div>
            )}
          </div>

          {/* 3. Upload Photo with Preview */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Upload Complaint Photo (Proof)
            </label>
            <p className="text-xs text-slate-400 mb-3">
              Supported formats: JPG, JPEG, PNG, and WEBP. (Max: 10MB)
            </p>

            {photoPreview ? (
              <div className="relative inline-block rounded-2xl overflow-hidden border border-white/20 bg-slate-800 shadow-md">
                <img
                  src={photoPreview}
                  alt="Upload preview"
                  className="max-h-56 w-auto object-cover rounded-2xl"
                />
                <button
                  type="button"
                  onClick={removePhoto}
                  className="absolute top-2 right-2 p-1.5 rounded-full bg-slate-900/80 text-rose-400 hover:text-white hover:bg-rose-600 transition-colors cursor-pointer"
                  title="Remove photo"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-white/15 hover:border-sky-500/50 rounded-2xl p-6 text-center cursor-pointer bg-slate-800/40 hover:bg-slate-800/70 transition-all flex flex-col items-center justify-center gap-2 group"
              >
                <Upload className="w-6 h-6 text-slate-400 group-hover:text-sky-400 transition-colors" />
                <span className="text-xs font-medium text-slate-300">
                  Click to select photo or drag and drop
                </span>
                <span className="text-[11px] text-slate-500">JPG, JPEG, PNG, WEBP</span>
              </div>
            )}
            <input
              ref={fileInputRef}
              type="file"
              accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
              onChange={handlePhotoChange}
              className="hidden"
            />
          </div>

          {/* 4. Conditional Logic: Did You Tell the Cook? */}
          <div className="pt-4 border-t border-white/10 space-y-4">
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
              Did You Tell the Cook? *
            </label>
            <div className="flex items-center gap-4">
              <label
                className={`flex items-center gap-2 px-5 py-2.5 rounded-xl border text-sm font-medium cursor-pointer transition-all ${
                  toldCook === 'yes'
                    ? 'border-sky-500 bg-sky-500/20 text-white'
                    : 'border-white/10 bg-slate-800/60 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <input
                  type="radio"
                  name="toldCook"
                  checked={toldCook === 'yes'}
                  onChange={() => setToldCook('yes')}
                  className="hidden"
                />
                <span>Yes, I told the cook</span>
              </label>

              <label
                className={`flex items-center gap-2 px-5 py-2.5 rounded-xl border text-sm font-medium cursor-pointer transition-all ${
                  toldCook === 'no'
                    ? 'border-sky-500 bg-sky-500/20 text-white'
                    : 'border-white/10 bg-slate-800/60 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <input
                  type="radio"
                  name="toldCook"
                  checked={toldCook === 'no'}
                  onChange={() => setToldCook('no')}
                  className="hidden"
                />
                <span>No, I did not</span>
              </label>
            </div>

            {/* CONDITIONAL: If YES */}
            {toldCook === 'yes' && (
              <div className="p-4 rounded-2xl border border-white/10 bg-slate-800/50 space-y-3 animate-fade-in">
                <label className="block text-xs font-semibold text-slate-200">
                  What did the cook reply to you? *
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {[
                    'Ignored',
                    'Misbehaved',
                    "Sorry, I won't repeat it.",
                    'Tried to convince you.',
                    'Other'
                  ].map((option) => (
                    <label
                      key={option}
                      className={`flex items-center gap-2 p-3 rounded-xl border text-xs font-medium cursor-pointer transition-all ${
                        cookReply === option
                          ? 'border-sky-400 bg-sky-500/20 text-white shadow-sm'
                          : 'border-white/5 bg-slate-900/60 text-slate-300 hover:bg-slate-900'
                      }`}
                    >
                      <input
                        type="radio"
                        name="cookReply"
                        checked={cookReply === option}
                        onChange={() => setCookReply(option as CookReplyChoice)}
                        className="hidden"
                      />
                      <span>{option}</span>
                    </label>
                  ))}
                </div>

                {cookReply === 'Other' && (
                  <div className="pt-2">
                    <input
                      type="text"
                      value={customReply}
                      onChange={(e) => setCustomReply(e.target.value)}
                      placeholder="Type what the cook replied or said..."
                      className="w-full px-4 py-2.5 rounded-xl border border-white/10 bg-slate-900 text-white placeholder-slate-500 text-xs focus:outline-none focus:border-sky-500"
                    />
                  </div>
                )}
              </div>
            )}

            {/* CONDITIONAL: If NO */}
            {toldCook === 'no' && (
              <div className="p-4 rounded-2xl border border-white/10 bg-slate-800/50 space-y-2 animate-fade-in">
                <label className="block text-xs font-semibold text-slate-200">
                  Why didn't you tell the cook? (Optional)
                </label>
                <input
                  type="text"
                  value={whyNotTold}
                  onChange={(e) => setWhyNotTold(e.target.value)}
                  placeholder="e.g. Counter was crowded, was getting late for class, cook looked aggressive"
                  className="w-full px-4 py-2.5 rounded-xl border border-white/10 bg-slate-900 text-white placeholder-slate-500 text-xs focus:outline-none focus:border-sky-500"
                />
              </div>
            )}
          </div>

          {/* 5. Suggestion Box */}
          <div className="pt-4 border-t border-white/10">
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Suggestion Box
            </label>
            <textarea
              rows={4}
              value={suggestion}
              onChange={(e) => setSuggestion(e.target.value)}
              placeholder="Share your suggestions to improve hostel food and services..."
              className="w-full px-4 py-3 rounded-2xl border border-white/10 bg-slate-800/80 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-sky-500 transition-colors leading-relaxed"
            />
          </div>

          {/* 6. Submit Feedback Button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-semibold text-sm shadow-xl hover:shadow-blue-500/25 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isSubmitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Submitting Anonymously...</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>Submit Feedback</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>

      {/* Animated Success Popup Modal */}
      {successData && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="w-full max-w-md rounded-3xl border border-emerald-500/30 bg-slate-900 p-6 sm:p-8 shadow-2xl text-center space-y-6 animate-scale-up">
            {/* Success Icon */}
            <div className="w-16 h-16 mx-auto rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30 shadow-lg shadow-emerald-500/20">
              <CheckCircle className="w-9 h-9" />
            </div>

            {/* EXACT English Message Required by Master Prompt */}
            <div>
              <h3 className="text-xl font-bold text-white tracking-tight">
                Your feedback is very valuable to us. Thank you for your feedback!
              </h3>
              <p className="text-xs text-slate-400 mt-2">
                Your complaint has been queued for warden and mess committee review with 100% student anonymity.
              </p>
            </div>

            {/* Complaint ID & Token box */}
            <div className="p-4 rounded-2xl bg-slate-800/80 border border-white/10 text-left space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                  Anonymous Complaint ID
                </span>
                <span className="px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-sky-500/20 text-sky-300">
                  {successData.complaintId}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 leading-normal">
                Save this Complaint ID to anonymously check when the warden opens your complaint.
              </p>
              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => copyComplaintId(successData.complaintId)}
                  className="flex-1 py-2 px-3 text-xs font-medium rounded-xl border border-white/10 bg-slate-700/60 hover:bg-slate-700 text-white flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copied ? 'Copied ID!' : 'Copy Complaint ID'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const id = successData.complaintId;
                    setSuccessData(null);
                    onTrackComplaint(id);
                  }}
                  className="py-2 px-3 text-xs font-medium rounded-xl bg-sky-600 hover:bg-sky-500 text-white flex items-center justify-center gap-1 transition-colors cursor-pointer"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Track Live</span>
                </button>
              </div>
            </div>

            {/* Close Button */}
            <button
              type="button"
              onClick={() => setSuccessData(null)}
              className="w-full py-3 px-4 rounded-xl border border-white/15 bg-white/5 hover:bg-white/10 text-white text-xs font-semibold transition-colors cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </section>
  );
};
