import React, { useState } from 'react';
import { Star, Clock, AlertCircle, CheckCircle, RefreshCw, MessageSquarePlus } from 'lucide-react';
import { MenuItem, MealCategory } from '../types';

interface TodayMenuProps {
  menus: MenuItem[];
  onRate: (menuId: string, rating: number) => Promise<void>;
  userRatings: Record<string, number>;
  onReportMeal: (category: MealCategory) => void;
  isLoading?: boolean;
}

const RATING_LABELS: Record<number, { text: string; color: string }> = {
  1: { text: '1 Star = Very Bad', color: 'text-rose-400 bg-rose-500/10 border-rose-500/20' },
  2: { text: '2 Stars = Bad', color: 'text-amber-400 bg-amber-500/10 border-amber-500/20' },
  3: { text: '3 Stars = Average', color: 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20' },
  4: { text: '4 Stars = Good', color: 'text-sky-400 bg-sky-500/10 border-sky-500/20' },
  5: { text: '5 Stars = Excellent', color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' }
};

export const TodayMenu: React.FC<TodayMenuProps> = ({
  menus,
  onRate,
  userRatings,
  onReportMeal,
  isLoading
}) => {
  const [hoveredStars, setHoveredStars] = useState<Record<string, number>>({});
  const [submittingId, setSubmittingId] = useState<string | null>(null);
  const [rateFeedback, setRateFeedback] = useState<Record<string, string>>({});

  const handleStarClick = async (menuId: string, rating: number) => {
    try {
      setSubmittingId(menuId);
      await onRate(menuId, rating);
      setRateFeedback((prev) => ({
        ...prev,
        [menuId]: `You rated this meal ${rating} / 5 (${RATING_LABELS[rating].text.split('=')[1]?.trim() || ''})`
      }));
      setTimeout(() => {
        setRateFeedback((prev) => {
          const copy = { ...prev };
          delete copy[menuId];
          return copy;
        });
      }, 4000);
    } finally {
      setSubmittingId(null);
    }
  };

  const categories: MealCategory[] = ['Breakfast', 'Lunch', 'Snacks', 'Dinner'];

  return (
    <section className="py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Section Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 pb-4 border-b border-white/10 gap-4">
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-sky-400">Daily Dining Quality</span>
          <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight mt-1">
            Today's Mess Menu &amp; Live Ratings
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Rate today's meals to help hostel management and the mess committee keep food quality high.
          </p>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          {Object.entries(RATING_LABELS).map(([score, info]) => (
            <span
              key={score}
              className={`px-2 py-0.5 rounded border text-[11px] font-medium ${info.color}`}
            >
              {info.text}
            </span>
          ))}
        </div>
      </div>

      {/* Grid of Menus */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {categories.map((category) => {
          const menu = menus.find((m) => m.category === category);
          const currentRating = menu ? userRatings[menu.id] || 0 : 0;
          const hovered = menu ? hoveredStars[menu.id] || 0 : 0;
          const displayStar = hovered > 0 ? hovered : currentRating;

          if (!menu) {
            return (
              <div
                key={category}
                className="rounded-2xl p-6 border border-white/10 bg-slate-900/40 backdrop-blur flex flex-col justify-between"
              >
                <div>
                  <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">{category}</span>
                  <h3 className="text-lg font-bold text-slate-300 mt-1">No Menu Set Yet</h3>
                  <p className="text-xs text-slate-500 mt-2">The warden/mess staff will update today's menu shortly.</p>
                </div>
              </div>
            );
          }

          return (
            <div
              key={menu.id}
              className="group rounded-2xl border border-white/10 bg-slate-900/60 backdrop-blur-md shadow-lg flex flex-col justify-between transition-all duration-300 hover:border-sky-500/30 p-5 space-y-4"
            >
              {/* Card Header: Category & Timing (No image) */}
              <div className="flex items-center justify-between pb-3 border-b border-white/10">
                <span className="px-3 py-1 rounded-full text-xs font-semibold bg-sky-500/15 text-sky-300 border border-sky-500/25">
                  {category}
                </span>
                <span className="text-xs font-mono text-slate-300 flex items-center gap-1.5 bg-slate-800/80 px-2.5 py-1 rounded-full border border-white/5">
                  <Clock className="w-3.5 h-3.5 text-sky-400" />
                  <span>{menu.timing}</span>
                </span>
              </div>

              {/* Body */}
              <div className="flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <h3 className="text-base font-bold text-white line-clamp-1">{menu.name}</h3>
                  <p className="text-xs text-slate-400 mt-1.5 leading-relaxed line-clamp-3">
                    {menu.items}
                  </p>
                </div>

                {/* Rating Stats */}
                <div className="pt-2 border-t border-white/5 space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1.5 font-mono">
                      <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                      <span className="text-white font-bold text-sm">
                        {menu.averageRating > 0 ? menu.averageRating.toFixed(1) : 'New'}
                      </span>
                      <span className="text-slate-500">/ 5.0</span>
                    </div>
                    <span className="text-slate-400 text-[11px] font-mono">
                      {menu.totalRatings} {menu.totalRatings === 1 ? 'rating' : 'ratings'}
                    </span>
                  </div>

                  {/* Star Rating Interactive Controls */}
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] text-slate-400 font-medium">
                        {currentRating > 0 ? 'Your Rating (Click to update):' : 'Rate this meal:'}
                      </span>
                      {displayStar > 0 && (
                        <span className="text-[11px] text-sky-300 font-medium">
                          {RATING_LABELS[displayStar]?.text.split('=')[1]?.trim()}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-1.5 mt-2">
                      {[1, 2, 3, 4, 5].map((starVal) => {
                        const isFilled = starVal <= displayStar;
                        return (
                          <button
                            key={starVal}
                            type="button"
                            disabled={submittingId === menu.id}
                            onMouseEnter={() =>
                              setHoveredStars((prev) => ({ ...prev, [menu.id]: starVal }))
                            }
                            onMouseLeave={() =>
                              setHoveredStars((prev) => {
                                const copy = { ...prev };
                                delete copy[menu.id];
                                return copy;
                              })
                            }
                            onClick={() => handleStarClick(menu.id, starVal)}
                            className="p-1 rounded hover:scale-125 transition-transform cursor-pointer focus:outline-none"
                            title={`Rate ${starVal} Star`}
                          >
                            <Star
                              className={`w-5 h-5 transition-colors ${
                                isFilled
                                  ? 'fill-amber-400 text-amber-400'
                                  : 'text-slate-600 hover:text-slate-400'
                              }`}
                            />
                          </button>
                        );
                      })}
                      {submittingId === menu.id && (
                        <RefreshCw className="w-3.5 h-3.5 text-sky-400 animate-spin ml-1" />
                      )}
                    </div>

                    {/* Feedback message */}
                    {rateFeedback[menu.id] && (
                      <div className="mt-2 text-[11px] text-emerald-400 flex items-center gap-1 animate-fade-in">
                        <CheckCircle className="w-3 h-3" />
                        <span>{rateFeedback[menu.id]}</span>
                      </div>
                    )}
                  </div>

                  {/* Report issue quick button */}
                  <button
                    onClick={() => onReportMeal(category)}
                    className="w-full mt-2 py-2 px-3 text-xs font-medium rounded-xl border border-white/10 text-slate-300 hover:text-rose-300 hover:border-rose-500/30 hover:bg-rose-500/5 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <AlertCircle className="w-3.5 h-3.5 text-rose-400" />
                    <span>Report {category} Issue</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
