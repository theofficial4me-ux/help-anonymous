import React, { useState, useEffect } from 'react';
import {
  Search,
  Filter,
  CheckCircle2,
  Clock,
  AlertCircle,
  Bookmark,
  Trash2,
  RotateCcw,
  Eye,
  EyeOff,
  User,
  Utensils,
  Calendar,
  MessageSquare,
  AlertTriangle,
  X,
  ExternalLink
} from 'lucide-react';
import { Complaint, ComplaintStatus, CookStaff, MealCategory } from '../types';

interface AdminComplaintsProps {
  adminToken: string;
  staffList: CookStaff[];
  onStatsRefresh: () => void;
}

export const AdminComplaints: React.FC<AdminComplaintsProps> = ({
  adminToken,
  staffList,
  onStatsRefresh
}) => {
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [activeTab, setActiveTab] = useState<string>('all');
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedStaff, setSelectedStaff] = useState('all');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  // Selected complaint modal for full read
  const [activeComplaint, setActiveComplaint] = useState<Complaint | null>(null);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [permanentDeleteTarget, setPermanentDeleteTarget] = useState<Complaint | null>(null);

  const fetchComplaints = async () => {
    setIsLoading(true);
    setError('');
    try {
      const params = new URLSearchParams();
      if (activeTab !== 'all') {
        params.append('status', activeTab);
      } else {
        params.append('status', 'all');
      }
      if (selectedCategory !== 'all') params.append('category', selectedCategory);
      if (selectedStaff !== 'all') params.append('cookStaff', selectedStaff);
      if (search.trim()) params.append('search', search.trim());

      const res = await fetch(`/api/admin/complaints?${params.toString()}`, {
        headers: { Authorization: `Bearer ${adminToken}` }
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to fetch complaints');
      setComplaints(data.complaints || []);
    } catch (err: any) {
      setError(err.message || 'Error loading complaints');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchComplaints();
  }, [activeTab, selectedCategory, selectedStaff]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchComplaints();
  };

  // Open complaint and trigger resident notification event
  const handleOpenComplaint = async (c: Complaint) => {
    setActiveComplaint(c);
    try {
      const res = await fetch(`/api/admin/complaints/${c.id}/open`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${adminToken}` }
      });
      const data = await res.json();
      if (data.complaint) {
        setComplaints((prev) =>
          prev.map((item) => (item.id === c.id ? { ...item, ...data.complaint } : item))
        );
        onStatsRefresh();
      }
    } catch (err) {
      console.error('Error recording complaint opened timestamp:', err);
    }
  };

  // Update status (pending, done, ignored, saved, trash)
  const handleUpdateStatus = async (complaintId: string, status: ComplaintStatus) => {
    try {
      const res = await fetch(`/api/admin/complaints/${complaintId}/status`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`
        },
        body: JSON.stringify({ status })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Status update failed');

      // Refresh list and stats
      fetchComplaints();
      onStatsRefresh();

      if (activeComplaint && activeComplaint.id === complaintId) {
        setActiveComplaint({ ...activeComplaint, status });
      }
    } catch (err: any) {
      alert(err.message || 'Could not update complaint status');
    }
  };

  // Permanently delete complaint from Trash
  const handlePermanentDelete = async (complaintId: string) => {
    try {
      const res = await fetch(`/api/admin/complaints/${complaintId}/permanent`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${adminToken}` }
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Permanent delete failed');

      setPermanentDeleteTarget(null);
      if (activeComplaint?.id === complaintId) setActiveComplaint(null);
      fetchComplaints();
      onStatsRefresh();
    } catch (err: any) {
      alert(err.message || 'Failed to permanently delete complaint');
    }
  };

  const getStatusBadge = (status: ComplaintStatus) => {
    switch (status) {
      case 'done':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
            <CheckCircle2 className="w-3 h-3" />
            Done
          </span>
        );
      case 'pending':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-500/20 text-amber-400 border border-amber-500/30">
            <Clock className="w-3 h-3" />
            Pending
          </span>
        );
      case 'saved':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-500/20 text-blue-400 border border-blue-500/30">
            <Bookmark className="w-3 h-3" />
            Saved
          </span>
        );
      case 'ignored':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-500/20 text-slate-400 border border-slate-500/30">
            <AlertCircle className="w-3 h-3" />
            Ignored
          </span>
        );
      case 'trash':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-500/20 text-rose-400 border border-rose-500/30">
            <Trash2 className="w-3 h-3" />
            Trash
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* 6 Tabs as required by Master Prompt: All, Pending, Done, Ignored, Saved, Deleted/Trash */}
      <div className="flex flex-wrap items-center gap-2 p-1.5 rounded-2xl bg-slate-900/80 border border-white/10 backdrop-blur-md">
        {[
          { key: 'all', label: 'All Complaints' },
          { key: 'pending', label: 'Pending (Orange)' },
          { key: 'done', label: 'Done (Green)' },
          { key: 'ignored', label: 'Ignored (Grey)' },
          { key: 'saved', label: 'Saved (Blue)' },
          { key: 'trash', label: 'Deleted / Trash' }
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
              activeTab === tab.key
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Search & Filters */}
      <div className="p-4 rounded-2xl bg-slate-900/60 border border-white/10 flex flex-col md:flex-row items-center gap-3">
        <form onSubmit={handleSearchSubmit} className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by Complaint ID, food item, or suggestion..."
            className="w-full pl-10 pr-4 py-2 text-xs rounded-xl border border-white/10 bg-slate-800 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
          />
        </form>

        <div className="flex items-center gap-2 w-full md:w-auto">
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-white/10 bg-slate-800 text-white focus:outline-none focus:border-blue-500"
          >
            <option value="all">All Meals</option>
            <option value="Breakfast">Breakfast</option>
            <option value="Lunch">Lunch</option>
            <option value="Snacks">Snacks</option>
            <option value="Dinner">Dinner</option>
          </select>

          <select
            value={selectedStaff}
            onChange={(e) => setSelectedStaff(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-white/10 bg-slate-800 text-white focus:outline-none focus:border-blue-500"
          >
            <option value="all">All Kitchen Counters / Staff</option>
            {staffList.map((s) => (
              <option key={s.id} value={s.name}>
                {s.name}
              </option>
            ))}
          </select>

          <button
            onClick={fetchComplaints}
            className="px-3 py-2 text-xs font-medium rounded-xl border border-white/10 text-slate-300 hover:text-white hover:bg-white/10"
            title="Refresh list"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Complaints List / Cards */}
      {isLoading ? (
        <div className="py-20 text-center">
          <div className="w-8 h-8 mx-auto border-2 border-blue-500/30 border-t-blue-500 rounded-full animate-spin" />
          <p className="text-xs text-slate-400 mt-3">Loading complaints...</p>
        </div>
      ) : complaints.length === 0 ? (
        <div className="py-16 text-center rounded-3xl border border-dashed border-white/10 bg-slate-900/30">
          <Utensils className="w-10 h-10 text-slate-600 mx-auto mb-2" />
          <h4 className="text-base font-semibold text-slate-300">No complaints found in this category</h4>
          <p className="text-xs text-slate-500 mt-1">Change filters or check other status tabs.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {complaints.map((c) => (
            <div
              key={c.id}
              className={`rounded-2xl border p-5 flex flex-col justify-between transition-all duration-200 ${
                !c.isOpened
                  ? 'border-sky-500/40 bg-slate-900/90 shadow-lg shadow-sky-500/5'
                  : 'border-white/10 bg-slate-900/60'
              }`}
            >
              <div className="space-y-3">
                {/* Top Row: ID & Status */}
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-bold text-sky-400">{c.id}</span>
                  <div className="flex items-center gap-1.5">
                    {c.isOpened ? (
                      <span className="flex items-center gap-1 text-[10px] text-emerald-400 font-mono" title={`First opened at ${c.firstOpenedAt}`}>
                        <Eye className="w-3 h-3" />
                        Opened
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-[10px] text-amber-400 font-semibold" title="Unread">
                        <EyeOff className="w-3 h-3" />
                        New
                      </span>
                    )}
                    {getStatusBadge(c.status)}
                  </div>
                </div>

                {/* Photo Thumbnail if uploaded */}
                {c.photoUrl && (
                  <div
                    onClick={() => setPreviewImage(c.photoUrl)}
                    className="relative aspect-video rounded-xl overflow-hidden bg-slate-800 cursor-pointer group border border-white/10"
                  >
                    <img
                      src={c.photoUrl}
                      alt={c.item}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-xs text-white gap-1">
                      <Eye className="w-4 h-4" /> Click to view proof
                    </div>
                  </div>
                )}

                {/* Complaint Title & Meta */}
                <div>
                  <h4 className="text-sm font-bold text-white line-clamp-1">{c.item}</h4>
                  <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-1">
                    <span>{c.category}</span>
                    <span>·</span>
                    <span>Cook: <strong className="text-slate-300 font-normal">{c.cookStaff || 'Unassigned'}</strong></span>
                  </div>
                </div>

                {/* Cook Reply info */}
                {c.toldCook === 'yes' ? (
                  <div className="text-[11px] p-2 rounded-lg bg-slate-800/60 border border-white/5 text-slate-300">
                    <span className="text-slate-400">Cook Response: </span>
                    <strong className="text-amber-300">{c.cookReply || c.customReply || 'Reported'}</strong>
                  </div>
                ) : (
                  <div className="text-[11px] text-slate-500 italic">
                    Student did not tell cook directly{c.whyNotTold ? ` (${c.whyNotTold})` : ''}
                  </div>
                )}

                {/* Suggestion Preview */}
                {c.suggestion && (
                  <p className="text-xs text-slate-400 bg-slate-800/40 p-2.5 rounded-xl border border-white/5 line-clamp-2">
                    "{c.suggestion}"
                  </p>
                )}

                {/* Timestamp */}
                <div className="text-[10px] font-mono text-slate-500">
                  Logged: {new Date(c.createdAt).toLocaleString()}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 mt-4 border-t border-white/5 flex flex-col gap-2">
                <button
                  onClick={() => handleOpenComplaint(c)}
                  className="w-full py-2 px-3 text-xs font-semibold rounded-xl bg-blue-600 hover:bg-blue-500 text-white transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Open &amp; Read Full</span>
                </button>

                {/* Quick Status Buttons */}
                {c.status !== 'trash' ? (
                  <div className="grid grid-cols-4 gap-1 pt-1">
                    <button
                      onClick={() => handleUpdateStatus(c.id, 'done')}
                      className={`py-1 text-[10px] font-medium rounded-lg border text-center transition-colors ${
                        c.status === 'done'
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 font-bold'
                          : 'border-white/10 text-slate-400 hover:text-emerald-400 hover:bg-emerald-500/10'
                      }`}
                      title="Mark Done"
                    >
                      Done
                    </button>
                    <button
                      onClick={() => handleUpdateStatus(c.id, 'pending')}
                      className={`py-1 text-[10px] font-medium rounded-lg border text-center transition-colors ${
                        c.status === 'pending'
                          ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 font-bold'
                          : 'border-white/10 text-slate-400 hover:text-amber-400 hover:bg-amber-500/10'
                      }`}
                      title="Mark Pending"
                    >
                      Pending
                    </button>
                    <button
                      onClick={() => handleUpdateStatus(c.id, 'saved')}
                      className={`py-1 text-[10px] font-medium rounded-lg border text-center transition-colors ${
                        c.status === 'saved'
                          ? 'bg-blue-500/20 text-blue-300 border-blue-500/40 font-bold'
                          : 'border-white/10 text-slate-400 hover:text-blue-400 hover:bg-blue-500/10'
                      }`}
                      title="Save for Meeting"
                    >
                      Save
                    </button>
                    <button
                      onClick={() => handleUpdateStatus(c.id, 'trash')}
                      className="py-1 text-[10px] font-medium rounded-lg border border-white/10 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                      title="Move to Trash"
                    >
                      Delete
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <button
                      onClick={() => handleUpdateStatus(c.id, 'pending')}
                      className="py-1.5 text-xs font-medium rounded-xl border border-white/10 bg-slate-800 text-sky-300 hover:bg-slate-700 flex items-center justify-center gap-1"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      Restore
                    </button>
                    <button
                      onClick={() => setPermanentDeleteTarget(c)}
                      className="py-1.5 text-xs font-medium rounded-xl bg-rose-600 hover:bg-rose-500 text-white flex items-center justify-center gap-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      Delete Forever
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Full Read Complaint Modal */}
      {activeComplaint && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl border border-white/10 bg-slate-900 p-6 sm:p-8 shadow-2xl relative space-y-6">
            <button
              onClick={() => setActiveComplaint(null)}
              className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-white hover:bg-white/10"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Header */}
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="font-mono text-sm font-bold text-sky-400">{activeComplaint.id}</span>
                {getStatusBadge(activeComplaint.status)}
                <span className="text-xs text-emerald-400 font-mono ml-auto">
                  Notification: "Your complaint has been opened"
                </span>
              </div>
              <h3 className="text-xl font-bold text-white tracking-tight">{activeComplaint.item}</h3>
              <p className="text-xs text-slate-400 mt-1">
                Meal: <strong className="text-white">{activeComplaint.category}</strong> · Logged on {new Date(activeComplaint.createdAt).toLocaleString()}
              </p>
            </div>

            {/* Photo */}
            {activeComplaint.photoUrl && (
              <div className="rounded-2xl overflow-hidden border border-white/10 bg-slate-800">
                <img
                  src={activeComplaint.photoUrl}
                  alt={activeComplaint.item}
                  className="w-full max-h-72 object-contain bg-black"
                />
              </div>
            )}

            {/* Detailed Info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-3.5 rounded-xl bg-slate-800/60 border border-white/5 space-y-1">
                <span className="text-[11px] font-semibold text-slate-400 uppercase">Cook Staff</span>
                <p className="text-sm font-medium text-white">{activeComplaint.cookStaff || 'Unassigned'}</p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-800/60 border border-white/5 space-y-1">
                <span className="text-[11px] font-semibold text-slate-400 uppercase">Cook Confrontation</span>
                <p className="text-sm font-medium text-white">
                  {activeComplaint.toldCook === 'yes' ? 'Student informed cook' : 'Student did not speak to cook'}
                </p>
              </div>

              {activeComplaint.toldCook === 'yes' && (
                <div className="sm:col-span-2 p-3.5 rounded-xl bg-slate-800/60 border border-white/5 space-y-1">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase">Cook's Response</span>
                  <p className="text-sm text-amber-300 font-medium">
                    {activeComplaint.cookReply || activeComplaint.customReply || 'No verbal response recorded'}
                  </p>
                </div>
              )}

              {activeComplaint.whyNotTold && (
                <div className="sm:col-span-2 p-3.5 rounded-xl bg-slate-800/60 border border-white/5 space-y-1">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase">Reason for Not Telling Cook</span>
                  <p className="text-sm text-slate-300">{activeComplaint.whyNotTold}</p>
                </div>
              )}
            </div>

            {/* Suggestion Box */}
            <div className="p-4 rounded-2xl bg-slate-800/60 border border-white/5 space-y-2">
              <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                Student Suggestion
              </span>
              <p className="text-sm text-slate-200 leading-relaxed whitespace-pre-wrap">
                {activeComplaint.suggestion || 'No suggestion entered with this complaint.'}
              </p>
            </div>

            {/* Timestamps */}
            <div className="p-3 rounded-xl bg-slate-950 border border-white/5 text-[11px] font-mono text-slate-400 space-y-1">
              <div>Created: {new Date(activeComplaint.createdAt).toLocaleString()}</div>
              <div>First Opened by Admin: {activeComplaint.firstOpenedAt ? new Date(activeComplaint.firstOpenedAt).toLocaleString() : 'Just now'}</div>
            </div>

            {/* Status Change Controls */}
            <div className="pt-4 border-t border-white/10 flex flex-wrap items-center gap-2">
              <span className="text-xs font-semibold text-slate-400 mr-2">Update Status:</span>
              <button
                onClick={() => handleUpdateStatus(activeComplaint.id, 'done')}
                className="px-3 py-1.5 text-xs font-semibold rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white"
              >
                Mark Done
              </button>
              <button
                onClick={() => handleUpdateStatus(activeComplaint.id, 'pending')}
                className="px-3 py-1.5 text-xs font-semibold rounded-xl bg-amber-600 hover:bg-amber-500 text-white"
              >
                Mark Pending
              </button>
              <button
                onClick={() => handleUpdateStatus(activeComplaint.id, 'saved')}
                className="px-3 py-1.5 text-xs font-semibold rounded-xl bg-blue-600 hover:bg-blue-500 text-white"
              >
                Save for Meeting
              </button>
              <button
                onClick={() => handleUpdateStatus(activeComplaint.id, 'ignored')}
                className="px-3 py-1.5 text-xs font-semibold rounded-xl bg-slate-700 hover:bg-slate-600 text-slate-200"
              >
                Ignore
              </button>
              <button
                onClick={() => handleUpdateStatus(activeComplaint.id, 'trash')}
                className="px-3 py-1.5 text-xs font-semibold rounded-xl bg-rose-900/60 hover:bg-rose-800 text-rose-200 ml-auto"
              >
                Move to Trash
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Image Preview Zoom Modal */}
      {previewImage && (
        <div
          onClick={() => setPreviewImage(null)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md cursor-pointer"
        >
          <div className="relative max-w-4xl max-h-[90vh]">
            <img src={previewImage} alt="Zoomed proof" className="max-w-full max-h-[85vh] rounded-2xl object-contain" />
            <p className="text-center text-xs text-slate-400 mt-2">Click anywhere to close</p>
          </div>
        </div>
      )}

      {/* Permanent Delete Confirmation Dialog */}
      {permanentDeleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="w-full max-w-md rounded-2xl border border-rose-500/30 bg-slate-900 p-6 space-y-4">
            <div className="w-12 h-12 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-base font-bold text-white">Permanently Delete Complaint?</h4>
              <p className="text-xs text-slate-400 mt-1">
                Are you sure you want to permanently delete complaint <strong className="text-white">{permanentDeleteTarget.id}</strong>? This action cannot be undone.
              </p>
            </div>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setPermanentDeleteTarget(null)}
                className="px-4 py-2 text-xs font-medium rounded-xl border border-white/10 text-slate-300 hover:bg-white/5"
              >
                Cancel
              </button>
              <button
                onClick={() => handlePermanentDelete(permanentDeleteTarget.id)}
                className="px-4 py-2 text-xs font-semibold rounded-xl bg-rose-600 hover:bg-rose-500 text-white"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
