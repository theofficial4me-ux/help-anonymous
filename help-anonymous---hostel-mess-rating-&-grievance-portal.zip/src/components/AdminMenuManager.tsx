import React, { useState } from 'react';
import { Plus, Edit2, Trash2, Check, Clock, Utensils, X, Image as ImageIcon } from 'lucide-react';
import { MenuItem, MealCategory } from '../types';

interface AdminMenuManagerProps {
  menus: MenuItem[];
  adminToken: string;
  onRefresh: () => void;
}

export const AdminMenuManager: React.FC<AdminMenuManagerProps> = ({
  menus,
  adminToken,
  onRefresh
}) => {
  const [editingMenu, setEditingMenu] = useState<Partial<MenuItem> | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState('');

  const handleOpenAdd = () => {
    setEditingMenu({
      category: 'Breakfast',
      name: '',
      items: '',
      timing: '7:30 AM - 9:30 AM',
      image: ''
    });
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingMenu?.name || !editingMenu?.items || !editingMenu?.category) {
      setError('Please provide meal name, items, and category.');
      return;
    }
    setIsSaving(true);
    setError('');

    try {
      const res = await fetch('/api/admin/menu', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`
        },
        body: JSON.stringify(editingMenu)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save menu');

      setEditingMenu(null);
      onRefresh();
    } catch (err: any) {
      setError(err.message || 'Error saving menu item');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this menu item?')) return;
    try {
      const res = await fetch(`/api/admin/menu/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${adminToken}` }
      });
      if (res.ok) onRefresh();
    } catch (err) {
      alert('Failed to delete menu item');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-900/80 border border-white/10 backdrop-blur-md">
        <div>
          <h3 className="text-base font-bold text-white">Daily Hostel Mess Menu Management</h3>
          <p className="text-xs text-slate-400">Add, edit, or adjust food items and timings for today's meals.</p>
        </div>
        <button
          onClick={handleOpenAdd}
          className="px-4 py-2 text-xs font-semibold rounded-xl bg-blue-600 hover:bg-blue-500 text-white flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add Menu Item</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {menus.map((m) => (
          <div key={m.id} className="rounded-2xl border border-white/10 bg-slate-900/60 p-5 flex flex-col justify-between space-y-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-sky-500/20 text-sky-300 border border-sky-500/30">
                  {m.category}
                </span>
                <span className="text-xs font-mono text-slate-400 flex items-center gap-1">
                  <Clock className="w-3 h-3 text-slate-500" />
                  {m.timing}
                </span>
              </div>

              <div>
                <h4 className="text-base font-bold text-white">{m.name}</h4>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">{m.items}</p>
              </div>
            </div>

            <div className="pt-3 border-t border-white/5 flex items-center justify-between">
              <div className="text-xs font-mono text-amber-400">
                ★ {m.averageRating > 0 ? m.averageRating.toFixed(1) : 'New'} ({m.totalRatings} ratings)
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setEditingMenu(m)}
                  className="p-1.5 rounded-lg border border-white/10 text-slate-300 hover:text-white hover:bg-white/10"
                  title="Edit menu"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => handleDelete(m.id)}
                  className="p-1.5 rounded-lg border border-white/10 text-rose-400 hover:text-rose-300 hover:bg-rose-500/10"
                  title="Delete menu"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Edit / Add Modal */}
      {editingMenu && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="w-full max-w-lg rounded-3xl border border-white/10 bg-slate-900 p-6 space-y-4 relative">
            <button
              onClick={() => setEditingMenu(null)}
              className="absolute top-5 right-5 p-1.5 rounded-full text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
            <h4 className="text-lg font-bold text-white">
              {editingMenu.id ? 'Edit Menu Item' : 'Add New Daily Menu Item'}
            </h4>

            {error && (
              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs">
                {error}
              </div>
            )}

            <form onSubmit={handleSave} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Meal Category</label>
                  <select
                    value={editingMenu.category}
                    onChange={(e) => setEditingMenu({ ...editingMenu, category: e.target.value as MealCategory })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-white/10 bg-slate-800 text-white focus:outline-none focus:border-blue-500"
                  >
                    <option value="Breakfast">Breakfast</option>
                    <option value="Lunch">Lunch</option>
                    <option value="Snacks">Snacks</option>
                    <option value="Dinner">Dinner</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Timing</label>
                  <input
                    type="text"
                    value={editingMenu.timing}
                    onChange={(e) => setEditingMenu({ ...editingMenu, timing: e.target.value })}
                    placeholder="e.g. 12:30 PM - 2:30 PM"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-white/10 bg-slate-800 text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Meal Title</label>
                <input
                  type="text"
                  required
                  value={editingMenu.name}
                  onChange={(e) => setEditingMenu({ ...editingMenu, name: e.target.value })}
                  placeholder="e.g. Special South Indian Breakfast Feast"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-white/10 bg-slate-800 text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Food Items List</label>
                <textarea
                  rows={3}
                  required
                  value={editingMenu.items}
                  onChange={(e) => setEditingMenu({ ...editingMenu, items: e.target.value })}
                  placeholder="Comma separated food items..."
                  className="w-full px-3 py-2 text-xs rounded-xl border border-white/10 bg-slate-800 text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingMenu(null)}
                  className="px-4 py-2 text-xs font-medium rounded-xl border border-white/10 text-slate-300 hover:bg-white/5"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-5 py-2 text-xs font-semibold rounded-xl bg-blue-600 hover:bg-blue-500 text-white"
                >
                  {isSaving ? 'Saving...' : 'Save Menu'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
