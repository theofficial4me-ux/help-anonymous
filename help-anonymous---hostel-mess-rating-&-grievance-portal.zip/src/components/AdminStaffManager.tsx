import React, { useState } from 'react';
import { Plus, Edit2, Trash2, User, Clock, ShieldCheck, X } from 'lucide-react';
import { CookStaff } from '../types';

interface AdminStaffManagerProps {
  staffList: CookStaff[];
  adminToken: string;
  onRefresh: () => void;
}

export const AdminStaffManager: React.FC<AdminStaffManagerProps> = ({
  staffList,
  adminToken,
  onRefresh
}) => {
  const [editingStaff, setEditingStaff] = useState<Partial<CookStaff> | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState('');

  const handleOpenAdd = () => {
    setEditingStaff({
      name: '',
      role: 'Cook Specialist',
      shift: 'All Shifts'
    });
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingStaff?.name || !editingStaff?.role) {
      setError('Staff name and role are required.');
      return;
    }

    setIsSaving(true);
    setError('');

    try {
      const res = await fetch('/api/admin/staff', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`
        },
        body: JSON.stringify(editingStaff)
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save staff');

      setEditingStaff(null);
      onRefresh();
    } catch (err: any) {
      setError(err.message || 'Error saving staff member');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Delete this staff member from mess records?')) return;
    try {
      const res = await fetch(`/api/admin/staff/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${adminToken}` }
      });
      if (res.ok) onRefresh();
    } catch (err) {
      alert('Failed to delete staff member');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-900/80 border border-white/10 backdrop-blur-md">
        <div>
          <h3 className="text-base font-bold text-white">Mess Cook Staff Directory</h3>
          <p className="text-xs text-slate-400">
            Registered kitchen cooks and counter supervisors selectable in student feedback.
          </p>
        </div>
        <button
          onClick={handleOpenAdd}
          className="px-4 py-2 text-xs font-semibold rounded-xl bg-blue-600 hover:bg-blue-500 text-white flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add Staff Member</span>
        </button>
      </div>

      {staffList.length === 0 ? (
        <div className="py-12 px-6 rounded-2xl border border-dashed border-white/10 bg-slate-900/30 text-center space-y-2">
          <User className="w-8 h-8 text-slate-500 mx-auto" />
          <h4 className="text-sm font-semibold text-slate-300">No Cook Staff Added Yet</h4>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Click "Add Staff Member" above to register your hostel's actual cooks, head chefs, and kitchen counter supervisors.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {staffList.map((staff) => (
            <div key={staff.id} className="p-4 rounded-2xl border border-white/10 bg-slate-900/60 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center text-slate-300 font-bold border border-white/10">
                  {staff.name.charAt(0)}
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">{staff.name}</h4>
                  <p className="text-xs text-sky-400">{staff.role}</p>
                  <span className="text-[10px] text-slate-500 font-mono">Shift: {staff.shift}</span>
                </div>
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => setEditingStaff(staff)}
                  className="p-1.5 rounded-lg border border-white/10 text-slate-400 hover:text-white hover:bg-white/5 cursor-pointer"
                  title="Edit staff"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => handleDelete(staff.id)}
                  className="p-1.5 rounded-lg border border-white/10 text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 cursor-pointer"
                  title="Delete staff"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Edit / Add Modal */}
      {editingStaff && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="w-full max-w-md rounded-3xl border border-white/10 bg-slate-900 p-6 space-y-4 relative">
            <button
              onClick={() => setEditingStaff(null)}
              className="absolute top-5 right-5 p-1.5 rounded-full text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
            <h4 className="text-base font-bold text-white">
              {editingStaff.id ? 'Edit Staff Member' : 'Add Cook Staff'}
            </h4>

            {error && (
              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs">
                {error}
              </div>
            )}

            <form onSubmit={handleSave} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Staff Name</label>
                <input
                  type="text"
                  required
                  value={editingStaff.name}
                  onChange={(e) => setEditingStaff({ ...editingStaff, name: e.target.value })}
                  placeholder="e.g. Ramesh Kumar"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-white/10 bg-slate-800 text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Kitchen Role</label>
                <input
                  type="text"
                  required
                  value={editingStaff.role}
                  onChange={(e) => setEditingStaff({ ...editingStaff, role: e.target.value })}
                  placeholder="e.g. Head Chef / Roti Maker / Curry Specialist"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-white/10 bg-slate-800 text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Assigned Shift</label>
                <input
                  type="text"
                  value={editingStaff.shift}
                  onChange={(e) => setEditingStaff({ ...editingStaff, shift: e.target.value })}
                  placeholder="e.g. Morning & Lunch, Dinner, All Shifts"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-white/10 bg-slate-800 text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingStaff(null)}
                  className="px-4 py-2 text-xs font-medium rounded-xl border border-white/10 text-slate-300 hover:bg-white/5"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-4 py-2 text-xs font-semibold rounded-xl bg-blue-600 hover:bg-blue-500 text-white"
                >
                  {isSaving ? 'Saving...' : 'Save Staff'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
