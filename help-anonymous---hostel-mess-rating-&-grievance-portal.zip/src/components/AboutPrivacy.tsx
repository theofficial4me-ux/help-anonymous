import React from 'react';
import { ShieldCheck, Lock, EyeOff, Server, FileText, CheckCircle2, AlertCircle } from 'lucide-react';
import { WebsiteSettings } from '../types';

interface AboutPrivacyProps {
  settings: WebsiteSettings;
  onNavigateFeedback: () => void;
}

export const AboutPrivacy: React.FC<AboutPrivacyProps> = ({ settings, onNavigateFeedback }) => {
  return (
    <section className="py-12 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
      {/* Hero Header */}
      <div className="text-center space-y-3">
        <span className="text-xs font-semibold uppercase tracking-wider text-sky-400">
          Privacy Architecture &amp; Ethics
        </span>
        <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
          Anonymous Privacy System &amp; Hostel Rights
        </h2>
        <p className="text-sm text-slate-400 max-w-xl mx-auto">
          Built on a non-negotiable principle: students must be able to speak truth about hostel food quality and staff behaviour without fear of victimisation.
        </p>
      </div>

      {/* 4 Privacy Pillars */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
        <div className="p-6 rounded-3xl border border-white/10 bg-slate-900/60 backdrop-blur-xl space-y-3">
          <div className="w-10 h-10 rounded-2xl bg-sky-500/20 text-sky-400 flex items-center justify-center border border-sky-500/30">
            <EyeOff className="w-5 h-5" />
          </div>
          <h4 className="text-base font-bold text-white">Zero Student Names or Emails</h4>
          <p className="text-xs text-slate-400 leading-relaxed">
            Our complaint records completely omit student identity, email, room number, and phone number. The database table stores only the complaint item, category, cook staff feedback, and optional photo proof.
          </p>
        </div>

        <div className="p-6 rounded-3xl border border-white/10 bg-slate-900/60 backdrop-blur-xl space-y-3">
          <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
            <Lock className="w-5 h-5" />
          </div>
          <h4 className="text-base font-bold text-white">No IP Address Exposure</h4>
          <p className="text-xs text-slate-400 leading-relaxed">
            Unlike standard web forms, IP addresses are never logged or exposed in the warden administration dashboard. Even database queries filter out telemetry to protect whistleblower students.
          </p>
        </div>

        <div className="p-6 rounded-3xl border border-white/10 bg-slate-900/60 backdrop-blur-xl space-y-3">
          <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
            <Server className="w-5 h-5" />
          </div>
          <h4 className="text-base font-bold text-white">Cryptographic Tracking Tokens</h4>
          <p className="text-xs text-slate-400 leading-relaxed">
            When you submit a complaint, a secure random token (e.g. <code className="text-sky-300 font-mono">CMP-7041</code>) is issued solely to you. You can inspect whether the warden opened your grievance without ever logging in.
          </p>
        </div>

        <div className="p-6 rounded-3xl border border-white/10 bg-slate-900/60 backdrop-blur-xl space-y-3">
          <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h4 className="text-base font-bold text-white">Warden Accountability Audit</h4>
          <p className="text-xs text-slate-400 leading-relaxed">
            Every complaint requires the warden to assign a status (Pending, Done, Ignored, Saved). Unaddressed complaints automatically flag in the weekly executive mess report.
          </p>
        </div>
      </div>

      {/* Detailed Technical Compliance Statement */}
      <div className="p-6 sm:p-8 rounded-3xl border border-white/10 bg-slate-900/80 space-y-4">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 text-emerald-400" />
          Full Student Welfare &amp; Mess Committee Agreement
        </h3>
        <ul className="space-y-2.5 text-xs text-slate-300">
          <li className="flex items-start gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
            <span>Students can submit feedback completely anonymously without logging into personal student accounts.</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
            <span>Daily meal ratings use an anonymous local token, permitting only 1 vote per meal per day while retaining rating update privileges.</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
            <span>Cook staff receive weekly reports showing constructive feedback rather than individual student identifiers.</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
            <span>When an administrator opens and reviews a student complaint, the student's tracking token silently updates: <em>"Your complaint has been opened."</em></span>
          </li>
        </ul>

        <div className="pt-4 border-t border-white/10">
          <button
            onClick={onNavigateFeedback}
            className="py-3 px-6 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs transition-colors cursor-pointer"
          >
            Submit an Anonymous Grievance Now
          </button>
        </div>
      </div>
    </section>
  );
};
