import React, { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, Megaphone, Wrench, Check, X, ShieldAlert } from 'lucide-react';
import { WebsiteUpdate } from '../types';

interface AdminUpdatesManagerProps {
  adminToken: string;
}

export const AdminUpdatesManager: React.FC<AdminUpdatesManagerProps> = ({ adminToken }) => {
  const [updates, setUpdates] = useState<WebsiteUpdate[]>([]);
  const [editingUpdate, setEditingUpdate] = useState<Partial<WebsiteUpdate> | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState('');

  const fetchUpdates = async () => {
    try {
      const res = await fetch('/api/updates');
      const data = await res.json();
      setUpdates(data.updates || []);
    } catch (err) {
      console.error('Failed to load updates:', err);
    }
  };

  useEffect(() => {
    fetchUpdates();
  }, []);

  const handleOpenAdd = () => {
    setEditingUpdate({
      version: 'v2.5.0',
      title: '',
      description: '',
      isAnnouncement: true,
      isMaintenance: false,
      active: true
    });
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUpdate?.title || !editingUpdate?.description) {
      setError('Title and description are required.');
      return;
    }

    setIsSaving(true);
    setError('');

    try {
      const res = await fetch('/api/admin/updates', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`
        },
        body: JSON.stringify(editingUpdate)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save update');

      setEditingUpdate(null);
      fetchUpdates();
    } catch (err: any) {
      setError(err.message || 'Error saving update');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Delete this announcement?')) return;
    try {
      const res = await fetch(`/api/admin/updates/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${adminToken}` }
      });
      if (res.ok) fetchUpdates();
    } catch (err) {
      alert('Failed to delete announcement');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-900/80 border border-white/10 backdrop-blur-md">
        <div>
          <h3 className="text-base font-bold text-white">Website Updates &amp; Announcements</h3>
          <p className="text-xs text-slate-400">
            Post new features, maintenance notices, and dining notices displayed on the student homepage.
          </p>
        </div>
        <button
          onClick={handleOpenAdd}
          className="px-4 py-2 text-xs font-semibold rounded-xl bg-blue-600 hover:bg-blue-500 text-white flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>New Announcement</span>
        </button>
      </div>

      <div className="space-y-3">
        {updates.map((up) => (
          <div key={up.id} className="p-4 rounded-2xl border border-white/10 bg-slate-900/60 flex items-start justify-between gap-4">
            <div className="flex items-start gap-3">
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                  up.isMaintenance ? 'bg-amber-500/20 text-amber-400' : 'bg-sky-500/20 text-sky-400'
                }`}
              >
                {up.isMaintenance ? <Wrench className="w-4 h-4" /> : <Megaphone className="w-4 h-4" />}
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs px-2 py-0.5 rounded bg-white/10 text-white font-bold">
                    {up.version}
                  </span>
                  <h4 className="text-sm font-bold text-white">{up.title}</h4>
                  {up.isMaintenance && (
                    <span className="text-[10px] font-semibold text-amber-300 bg-amber-500/20 px-2 py-0.5 rounded">
                      Maintenance Notice
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">{up.description}</p>
                <span className="text-[10px] text-slate-500 font-mono">Published: {up.date}</span>
              </div>
            </div>

            <div className="flex items-center gap-1 shrink-0">
              <button
                onClick={() => setEditingUpdate(up)}
                className="p-1.5 rounded-lg border border-white/10 text-slate-400 hover:text-white"
              >
                <Edit2 className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => handleDelete(up.id)}
                className="p-1.5 rounded-lg border border-white/10 text-rose-400 hover:text-rose-300"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Edit / Add Modal */}
      {editingUpdate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="w-full max-w-lg rounded-3xl border border-white/10 bg-slate-900 p-6 space-y-4 relative">
            <button
              onClick={() => setEditingUpdate(null)}
              className="absolute top-5 right-5 p-1.5 rounded-full text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
            <h4 className="text-base font-bold text-white">
              {editingUpdate.id ? 'Edit Announcement' : 'Publish New Announcement'}
            </h4>

            {error && (
              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs">
                {error}
              </div>
            )}

            <form onSubmit={handleSave} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Version Tag</label>
                  <input
                    type="text"
                    value={editingUpdate.version}
                    onChange={(e) => setEditingUpdate({ ...editingUpdate, version: e.target.value })}
                    placeholder="v2.5.0"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-white/10 bg-slate-800 text-white focus:outline-none focus:border-blue-500 font-mono"
                  />
                </div>

                <div className="flex flex-col justify-end">
                  <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer mb-2">
                    <input
                      type="checkbox"
                      checked={editingUpdate.isMaintenance}
                      onChange={(e) => setEditingUpdate({ ...editingUpdate, isMaintenance: e.target.checked })}
                      className="rounded border-white/20 text-blue-600 focus:ring-0"
                    />
                    <span>Maintenance Notice</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Announcement Title</label>
                <input
                  type="text"
                  required
                  value={editingUpdate.title}
                  onChange={(e) => setEditingUpdate({ ...editingUpdate, title: e.target.value })}
                  placeholder="e.g. Special Festival Feast or Kitchen Deep Cleaning"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-white/10 bg-slate-800 text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Description</label>
                <textarea
                  rows={3}
                  required
                  value={editingUpdate.description}
                  onChange={(e) => setEditingUpdate({ ...editingUpdate, description: e.target.value })}
                  placeholder="Details for students..."
                  className="w-full px-3 py-2 text-xs rounded-xl border border-white/10 bg-slate-800 text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingUpdate(null)}
                  className="px-4 py-2 text-xs font-medium rounded-xl border border-white/10 text-slate-300 hover:bg-white/5"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-4 py-2 text-xs font-semibold rounded-xl bg-blue-600 hover:bg-blue-500 text-white"
                >
                  {isSaving ? 'Publishing...' : 'Publish Update'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
