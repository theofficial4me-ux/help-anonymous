import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  LogOut,
  BarChart3,
  ListFilter,
  FileSpreadsheet,
  UtensilsCrossed,
  Users,
  Palette,
  Megaphone,
  Settings,
  Star,
  Clock,
  CheckCircle2,
  AlertCircle,
  Bookmark,
  TrendingUp,
  RefreshCw,
  Home,
  AlertTriangle,
  Key,
  Lock
} from 'lucide-react';
import { AdminComplaints } from './AdminComplaints';
import { AdminWeeklyReport } from './AdminWeeklyReport';
import { AdminMenuManager } from './AdminMenuManager';
import { AdminStaffManager } from './AdminStaffManager';
import { AdminCustomization } from './AdminCustomization';
import { AdminUpdatesManager } from './AdminUpdatesManager';
import { AdminSettings } from './AdminSettings';
import { MenuItem, CookStaff, WebsiteSettings } from '../types';

interface AdminDashboardProps {
  adminToken: string;
  username: string;
  onLogout: () => void;
  onReturnToStudentHome: () => void;
  settings: WebsiteSettings;
  onSettingsUpdated: (newSettings: WebsiteSettings) => void;
  menus: MenuItem[];
  staffList: CookStaff[];
  onRefreshData: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  adminToken,
  username,
  onLogout,
  onReturnToStudentHome,
  settings,
  onSettingsUpdated,
  menus,
  staffList,
  onRefreshData
}) => {
  const [currentUsername, setCurrentUsername] = useState(username);
  const [activeSection, setActiveSection] = useState<
    'overview' | 'complaints' | 'reports' | 'menus' | 'staff' | 'customization' | 'updates' | 'settings'
  >('overview');

  const [stats, setStats] = useState<any | null>(null);
  const [isLoadingStats, setIsLoadingStats] = useState(false);

  const fetchStats = async () => {
    setIsLoadingStats(true);
    try {
      const res = await fetch('/api/admin/stats', {
        headers: { Authorization: `Bearer ${adminToken}` }
      });
      const data = await res.json();
      setStats(data);
    } catch (err) {
      console.error('Failed to load stats:', err);
    } finally {
      setIsLoadingStats(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      {/* Top Admin Bar */}
      <header className="sticky top-0 z-40 w-full backdrop-blur-xl border-b border-white/10 bg-slate-900/90 px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-bold text-white tracking-tight">Hostel Administration Portal</span>
            <span className="text-[10px] text-slate-400 font-mono">Logged in as: {currentUsername}</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveSection('settings')}
            className="px-3 py-1.5 text-xs font-semibold rounded-xl border border-sky-500/30 bg-sky-500/15 text-sky-300 hover:bg-sky-500/25 flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Change Username & Password"
          >
            <Key className="w-3.5 h-3.5" />
            <span>Change Username / Password</span>
          </button>
          <button
            onClick={onReturnToStudentHome}
            className="px-3 py-1.5 text-xs font-medium rounded-xl border border-white/10 text-slate-300 hover:text-white hover:bg-white/5 flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Home className="w-3.5 h-3.5" />
            <span>Student View</span>
          </button>
          <button
            onClick={fetchStats}
            className="p-2 rounded-xl border border-white/10 text-slate-400 hover:text-white hover:bg-white/5 transition-colors"
            title="Refresh statistics"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoadingStats ? 'animate-spin text-sky-400' : ''}`} />
          </button>
          <button
            onClick={onLogout}
            className="px-3 py-1.5 text-xs font-semibold rounded-xl bg-rose-600/20 border border-rose-500/30 text-rose-300 hover:bg-rose-600 hover:text-white flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </header>

      {/* Main Admin Body */}
      <div className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8 flex-1 space-y-8">
        {/* Navigation Tabs */}
        <div className="flex flex-wrap items-center gap-2 p-1.5 rounded-2xl bg-slate-900/80 border border-white/10 backdrop-blur-md">
          {[
            { id: 'overview', label: 'Live Dashboard', icon: BarChart3 },
            { id: 'complaints', label: 'Complaint Queue', icon: ListFilter },
            { id: 'reports', label: 'Weekly Warden Report', icon: FileSpreadsheet },
            { id: 'menus', label: 'Menu Manager', icon: UtensilsCrossed },
            { id: 'staff', label: 'Cook Staff', icon: Users },
            { id: 'customization', label: 'Website & 10 Themes', icon: Palette },
            { id: 'updates', label: 'Announcements', icon: Megaphone },
            { id: 'settings', label: 'Change Username & Password', icon: Key }
          ].map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => setActiveSection(item.id as any)}
                className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
                  activeSection === item.id
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>

        {/* 1. OVERVIEW DASHBOARD */}
        {activeSection === 'overview' && stats && (
          <div className="space-y-8 animate-fade-in">
            {/* 8 Statistics Cards as requested in Section 5 */}
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
              {[
                { label: 'Total Complaints', value: stats.totalComplaints, color: 'text-white', bg: 'bg-slate-900' },
                { label: 'New / Unopened', value: stats.newComplaints, color: 'text-sky-400', bg: 'bg-sky-950/40' },
                { label: 'Pending Action', value: stats.pendingComplaints, color: 'text-amber-400', bg: 'bg-amber-950/40' },
                { label: 'Completed', value: stats.completedComplaints, color: 'text-emerald-400', bg: 'bg-emerald-950/40' },
                { label: 'Ignored', value: stats.ignoredComplaints, color: 'text-slate-400', bg: 'bg-slate-900' },
                { label: 'Saved (Meeting)', value: stats.savedComplaints, color: 'text-blue-400', bg: 'bg-blue-950/40' },
                { label: 'Avg Rating', value: `${stats.averageRating} ★`, color: 'text-amber-300', bg: 'bg-slate-900' },
                { label: 'Total Ratings', value: stats.totalRatings, color: 'text-slate-300', bg: 'bg-slate-900' }
              ].map((card, idx) => (
                <div key={idx} className={`p-4 rounded-2xl border border-white/10 ${card.bg} space-y-1`}>
                  <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block truncate">
                    {card.label}
                  </span>
                  <div className={`text-xl font-bold font-mono ${card.color}`}>{card.value}</div>
                </div>
              ))}
            </div>

            {/* Visual Charts & Analytics */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Daily Complaint Statistics (Last 7 Days Bar representation) */}
              <div className="rounded-3xl border border-white/10 bg-slate-900/60 backdrop-blur-xl p-6 space-y-4">
                <h4 className="text-xs font-semibold text-sky-400 uppercase tracking-wider flex items-center justify-between">
                  <span>Daily Complaint Trends</span>
                  <TrendingUp className="w-3.5 h-3.5" />
                </h4>
                <div className="space-y-3 pt-2">
                  {Object.entries(stats.dailyStats || {}).map(([dayStr, count]) => {
                    const dayCount = count as number;
                    const maxVal = Math.max(1, ...Object.values(stats.dailyStats).map((v) => Number(v)));
                    const pct = Math.min(100, Math.round((dayCount / maxVal) * 100));
                    return (
                      <div key={dayStr} className="space-y-1">
                        <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
                          <span>{dayStr}</span>
                          <span className="text-white font-bold">{dayCount} grievances</span>
                        </div>
                        <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full transition-all duration-500"
                            style={{ width: `${Math.max(5, pct)}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Meal-Wise Ratings */}
              <div className="rounded-3xl border border-white/10 bg-slate-900/60 backdrop-blur-xl p-6 space-y-4">
                <h4 className="text-xs font-semibold text-amber-400 uppercase tracking-wider flex items-center justify-between">
                  <span>Meal-Wise Quality Ratings</span>
                  <Star className="w-3.5 h-3.5" />
                </h4>
                <div className="space-y-3 pt-2">
                  {Object.entries(stats.mealRatings || {}).map(([meal, data]: [string, any]) => {
                    const pct = Math.round((data.average / 5.0) * 100);
                    return (
                      <div key={meal} className="space-y-1">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="font-semibold text-slate-300">{meal}</span>
                          <span className="text-amber-400 font-mono font-bold">
                            {data.average > 0 ? `${data.average} ★` : 'No votes'} ({data.count} votes)
                          </span>
                        </div>
                        <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                          <div
                            className="h-full bg-amber-400 rounded-full transition-all duration-500"
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Most Complained Food Items & Staff distribution */}
              <div className="rounded-3xl border border-white/10 bg-slate-900/60 backdrop-blur-xl p-6 space-y-4">
                <h4 className="text-xs font-semibold text-rose-400 uppercase tracking-wider flex items-center justify-between">
                  <span>Most Complained Food Items</span>
                  <AlertTriangle className="w-3.5 h-3.5" />
                </h4>
                <div className="space-y-2 pt-1">
                  {stats.topComplainedItems?.length === 0 ? (
                    <p className="text-xs text-slate-500">No issues flagged.</p>
                  ) : (
                    stats.topComplainedItems.map((item: any, idx: number) => (
                      <div key={idx} className="flex items-center justify-between p-2.5 rounded-xl bg-slate-800/60 border border-white/5 text-xs">
                        <span className="font-medium text-slate-200">{item.item}</span>
                        <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-rose-500/20 text-rose-300 font-bold">
                          {item.count} {item.count === 1 ? 'report' : 'reports'}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>

            {/* Quick Link to Complaint Queue */}
            <div className="p-6 rounded-3xl border border-white/10 bg-slate-900/40 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <h4 className="text-base font-bold text-white">Review &amp; Action Pending Complaints</h4>
                <p className="text-xs text-slate-400">
                  Open complaints to investigate cook responses and trigger the silent resident status notice.
                </p>
              </div>
              <button
                onClick={() => setActiveSection('complaints')}
                className="px-5 py-2.5 text-xs font-semibold rounded-xl bg-blue-600 hover:bg-blue-500 text-white cursor-pointer"
              >
                Go to Complaint Queue
              </button>
            </div>

            {/* Quick Banner to Change Username & Password */}
            <div className="p-6 rounded-3xl border border-sky-500/25 bg-sky-950/20 backdrop-blur-md flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-sky-500/20 text-sky-400 flex items-center justify-center border border-sky-500/30 shrink-0">
                  <Key className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Administrator Credentials &amp; Security</h4>
                  <p className="text-xs text-slate-300">
                    Logged in as: <strong className="text-sky-300 font-mono">{currentUsername}</strong>. You can update your admin username and password anytime.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setActiveSection('settings')}
                className="px-4 py-2 text-xs font-semibold rounded-xl bg-sky-600 hover:bg-sky-500 text-white shrink-0 cursor-pointer shadow-md transition-colors flex items-center gap-1.5"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Change Username &amp; Password</span>
              </button>
            </div>
          </div>
        )}

        {/* 2. COMPLAINTS QUEUE TAB */}
        {activeSection === 'complaints' && (
          <AdminComplaints
            adminToken={adminToken}
            staffList={staffList}
            onStatsRefresh={fetchStats}
          />
        )}

        {/* 3. WEEKLY WARDEN REPORT TAB */}
        {activeSection === 'reports' && <AdminWeeklyReport adminToken={adminToken} />}

        {/* 4. MENUS TAB */}
        {activeSection === 'menus' && (
          <AdminMenuManager
            menus={menus}
            adminToken={adminToken}
            onRefresh={onRefreshData}
          />
        )}

        {/* 5. COOK STAFF TAB */}
        {activeSection === 'staff' && (
          <AdminStaffManager
            staffList={staffList}
            adminToken={adminToken}
            onRefresh={onRefreshData}
          />
        )}

        {/* 6. CUSTOMIZATION & 10 THEMES */}
        {activeSection === 'customization' && (
          <AdminCustomization
            settings={settings}
            adminToken={adminToken}
            onSettingsUpdated={onSettingsUpdated}
          />
        )}

        {/* 7. ANNOUNCEMENTS & UPDATES */}
        {activeSection === 'updates' && <AdminUpdatesManager adminToken={adminToken} />}

        {/* 8. ADMIN SETTINGS & SECURITY */}
        {activeSection === 'settings' && (
          <AdminSettings
            adminToken={adminToken}
            onUsernameChanged={(newU) => setCurrentUsername(newU)}
          />
        )}
      </div>
    </div>
  );
};
