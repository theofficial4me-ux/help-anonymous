import React, { useState } from 'react';
import { ShieldCheck, Utensils, MessageSquarePlus, Search, Lock, Menu, X, Sparkles } from 'lucide-react';
import { WebsiteSettings } from '../types';

interface HeaderProps {
  settings: WebsiteSettings;
  currentTab: string;
  onSelectTab: (tab: string) => void;
  isAdminLoggedIn: boolean;
  onOpenAdminLogin: () => void;
  onOpenAdminDashboard: () => void;
  onOpenThemeQuickSwitch: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  settings,
  currentTab,
  onSelectTab,
  isAdminLoggedIn,
  onOpenAdminLogin,
  onOpenAdminDashboard,
  onOpenThemeQuickSwitch
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNav = (tab: string) => {
    onSelectTab(tab);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-xl border-b border-white/10 transition-colors"
      style={{
        backgroundColor: settings.layout.headerStyle === 'glass' ? 'rgba(7, 11, 20, 0.8)' : settings.colors.background,
        borderColor: settings.colors.border
      }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand wordmark (single text element wordmark) */}
        <div className="flex items-center gap-3 shrink-0 cursor-pointer" onClick={() => handleNav('home')}>
          <div className="w-9 h-9 rounded-xl flex items-center justify-center text-white shadow-md"
            style={{ backgroundColor: settings.colors.primary }}
          >
            <ShieldCheck className="w-5 h-5 text-white" />
          </div>
          <div className="flex flex-col">
            <span className="text-lg font-bold tracking-tight text-white whitespace-nowrap">
              {settings.websiteName || 'HELP ANONYMOUS'}
            </span>
          </div>
        </div>

        {/* Zone 2: 4–5 concise single-line text links */}
        <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-slate-300">
          <button
            onClick={() => handleNav('home')}
            className={`transition-colors whitespace-nowrap cursor-pointer hover:text-white ${currentTab === 'home' ? 'text-white font-semibold' : ''}`}
          >
            Home
          </button>
          <button
            onClick={() => handleNav('menu')}
            className={`transition-colors whitespace-nowrap cursor-pointer hover:text-white ${currentTab === 'menu' ? 'text-white font-semibold' : ''}`}
          >
            Today's Menu
          </button>
          <button
            onClick={() => handleNav('feedback')}
            className={`transition-colors whitespace-nowrap cursor-pointer hover:text-white ${currentTab === 'feedback' ? 'text-white font-semibold' : ''}`}
          >
            Feedback &amp; Complaint
          </button>
          <button
            onClick={() => handleNav('tracker')}
            className={`transition-colors whitespace-nowrap cursor-pointer hover:text-white ${currentTab === 'tracker' ? 'text-white font-semibold' : ''}`}
          >
            Track Status
          </button>
          <button
            onClick={() => handleNav('about')}
            className={`transition-colors whitespace-nowrap cursor-pointer hover:text-white ${currentTab === 'about' ? 'text-white font-semibold' : ''}`}
          >
            Privacy Policy
          </button>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onOpenThemeQuickSwitch}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-white/10 text-slate-300 hover:text-white hover:bg-white/5 transition-colors cursor-pointer"
            title="Theme Palette"
          >
            <Sparkles className="w-3.5 h-3.5 text-sky-400" />
            <span className="capitalize">{settings.activeTheme.replace('-', ' ')}</span>
          </button>

          {isAdminLoggedIn ? (
            <button
              onClick={onOpenAdminDashboard}
              className="flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-xl text-white shadow-md transition-all cursor-pointer hover:opacity-90 whitespace-nowrap"
              style={{ backgroundColor: settings.colors.button }}
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Admin Dashboard</span>
            </button>
          ) : (
            <button
              onClick={onOpenAdminLogin}
              className="flex items-center gap-2 px-4 py-2 text-xs font-medium rounded-xl border border-white/15 text-white hover:bg-white/10 transition-all cursor-pointer whitespace-nowrap"
            >
              <Lock className="w-3.5 h-3.5 text-slate-400" />
              <span>Admin Login</span>
            </button>
          )}

          {/* Mobile hamburger */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 focus:outline-none"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden px-4 pt-2 pb-6 space-y-2 border-t border-white/10 bg-slate-950/95 backdrop-blur-2xl">
          <button
            onClick={() => handleNav('home')}
            className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium ${currentTab === 'home' ? 'bg-white/10 text-white' : 'text-slate-300 hover:bg-white/5'}`}
          >
            Home
          </button>
          <button
            onClick={() => handleNav('menu')}
            className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium ${currentTab === 'menu' ? 'bg-white/10 text-white' : 'text-slate-300 hover:bg-white/5'}`}
          >
            Today's Mess Menu
          </button>
          <button
            onClick={() => handleNav('feedback')}
            className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium ${currentTab === 'feedback' ? 'bg-white/10 text-white' : 'text-slate-300 hover:bg-white/5'}`}
          >
            Submit Feedback &amp; Complaint
          </button>
          <button
            onClick={() => handleNav('tracker')}
            className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium ${currentTab === 'tracker' ? 'bg-white/10 text-white' : 'text-slate-300 hover:bg-white/5'}`}
          >
            Track Grievance Status
          </button>
          <button
            onClick={() => handleNav('about')}
            className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium ${currentTab === 'about' ? 'bg-white/10 text-white' : 'text-slate-300 hover:bg-white/5'}`}
          >
            Privacy &amp; Anonymity Policy
          </button>
          <div className="pt-2 border-t border-white/10 flex items-center justify-between">
            <button
              onClick={() => {
                onOpenThemeQuickSwitch();
                setMobileMenuOpen(false);
              }}
              className="px-3 py-2 text-xs rounded-lg border border-white/10 text-slate-300 flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5 text-sky-400" />
              Theme: {settings.activeTheme}
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
