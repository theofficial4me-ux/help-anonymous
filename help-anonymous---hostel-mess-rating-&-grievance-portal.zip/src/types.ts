export type MealCategory = 'Breakfast' | 'Lunch' | 'Snacks' | 'Dinner';

export interface MenuItem {
  id: string;
  category: MealCategory;
  name: string;
  items: string;
  timing: string;
  image: string;
  averageRating: number;
  totalRatings: number;
}

export interface MealRating {
  id: string;
  menuId: string;
  category: MealCategory;
  rating: number; // 1 to 5
  studentToken: string;
  date: string; // YYYY-MM-DD
  createdAt: string;
  updatedAt: string;
}

export interface CookStaff {
  id: string;
  name: string;
  role: string;
  shift: string;
  avatar?: string;
}

export type ComplaintStatus = 'pending' | 'done' | 'ignored' | 'saved' | 'trash';

export type CookReplyChoice = 
  | 'Ignored'
  | 'Misbehaved'
  | "Sorry, I won't repeat it."
  | 'Tried to convince you.'
  | 'Other';

export interface Complaint {
  id: string; // e.g. "CMP-8492"
  trackingToken: string;
  item: string;
  photoUrl: string;
  cookStaff: string;
  category: MealCategory;
  toldCook: 'yes' | 'no';
  cookReply?: CookReplyChoice;
  customReply?: string;
  whyNotTold?: string;
  suggestion?: string;
  status: ComplaintStatus;
  isOpened: boolean;
  firstOpenedAt: string | null;
  lastOpenedAt: string | null;
  createdAt: string;
  updatedAt: string;
  statusHistory: Array<{
    status: ComplaintStatus;
    timestamp: string;
    note?: string;
  }>;
}

export interface WebsiteUpdate {
  id: string;
  version: string;
  title: string;
  description: string;
  isAnnouncement: boolean;
  isMaintenance: boolean;
  active: boolean;
  date: string;
}

export type ThemeName =
  | 'liquid-glass'
  | 'claymorphism'
  | 'skeuomorphism'
  | 'neumorphism'
  | 'glassmorphism'
  | 'brutalism'
  | 'minimalism'
  | 'maximalism'
  | 'bento-grid'
  | 'spatial-ui';

export interface WebsiteSettings {
  websiteName: string;
  tagline: string;
  logoUrl: string;
  faviconUrl: string;
  heroHeading: string;
  welcomeMessage: string;
  footerText: string;
  activeTheme: ThemeName;
  typography: {
    fontFamily: string;
    headingFont: string;
    fontSize: 'small' | 'medium' | 'large';
    fontWeight: 'normal' | 'medium' | 'bold';
    lineHeight: 'tight' | 'normal' | 'relaxed';
  };
  colors: {
    primary: string;
    secondary: string;
    background: string;
    cardBackground: string;
    text: string;
    heading: string;
    button: string;
    border: string;
    accent: string;
  };
  layout: {
    headerStyle: 'glass' | 'solid' | 'minimal';
    cardStyle: 'glass' | 'flat' | 'elevated' | 'outlined';
    buttonShape: 'rounded' | 'rounded-xl' | 'pill' | 'sharp';
    borderRadius: string;
    shadowIntensity: 'none' | 'light' | 'medium' | 'heavy';
    spacing: 'compact' | 'normal' | 'spacious';
  };
}

export interface ReminderSettings {
  reminderEnabled: boolean;
  reportDay: string; // "Monday", "Sunday", etc.
  reminderTime: string; // "09:00"
  emailNotification: string;
  lastTriggeredAlert?: string;
}

export interface WeeklyReportSummary {
  reportId: string;
  generatedDate: string;
  startDate: string;
  endDate: string;
  totalComplaints: number;
  totalResolved: number;
  totalPending: number;
  totalIgnored: number;
  totalSaved: number;
  averageMealRating: number;
  mealRatings: Record<MealCategory, { average: number; count: number }>;
  topComplainedItems: Array<{ item: string; count: number; category: string }>;
  staffComplaints: Array<{ staff: string; count: number }>;
  recentSuggestions: string[];
  recommendations: string[];
  weeklyRatingComparison: {
    previousWeek: number;
    currentWeek: number;
    trend: 'up' | 'down' | 'neutral';
    percentageChange: number;
  };
}
