import { ThemeName } from './types';

export interface ThemeDefinition {
  id: ThemeName;
  name: string;
  tagline: string;
  description: string;
  primaryColor: string;
  accentColor: string;
  backgroundColor: string;
  cardBackground: string;
  textColor: string;
  borderStyle: string;
  shadowStyle: string;
  borderRadius: string;
  fontFamily: string;
  headingFont: string;
}

export const THEME_DEFINITIONS: Record<ThemeName, ThemeDefinition> = {
  'liquid-glass': {
    id: 'liquid-glass',
    name: 'Liquid Glass (Default)',
    tagline: 'Modern ethereal fluid glass with luminous accents',
    description: 'High-clarity frosted acrylic surfaces with glowing cyan-blue highlights and subtle ambient lighting.',
    primaryColor: '#3b82f6',
    accentColor: '#38bdf8',
    backgroundColor: '#070b14',
    cardBackground: 'rgba(15, 23, 42, 0.65)',
    textColor: '#f8fafc',
    borderStyle: '1px solid rgba(148, 163, 184, 0.15)',
    shadowStyle: '0 8px 32px 0 rgba(0, 0, 0, 0.37)',
    borderRadius: '1.25rem',
    fontFamily: 'Plus Jakarta Sans',
    headingFont: 'Outfit'
  },
  'claymorphism': {
    id: 'claymorphism',
    name: 'Claymorphism',
    tagline: 'Tactile, soft, pillowy 3D clay aesthetic',
    description: 'Rounded pillowy surfaces with warm dual-tone inner and outer drop shadows for a friendly modern vibe.',
    primaryColor: '#6366f1',
    accentColor: '#ec4899',
    backgroundColor: '#eef2ff',
    cardBackground: '#edf2f7',
    textColor: '#1e293b',
    borderStyle: '1px solid rgba(255, 255, 255, 0.8)',
    shadowStyle: '12px 12px 24px #c2c9d6, -12px -12px 24px #ffffff',
    borderRadius: '2rem',
    fontFamily: 'DM Sans',
    headingFont: 'Outfit'
  },
  'skeuomorphism': {
    id: 'skeuomorphism',
    name: 'Skeuomorphism',
    tagline: 'Tactile hardware dials, brushed metals and insets',
    description: 'Realistic textured surfaces inspired by physical mess hall brass bells, brushed steel trays, and embossed cards.',
    primaryColor: '#eab308',
    accentColor: '#f97316',
    backgroundColor: '#272a30',
    cardBackground: '#26292f',
    textColor: '#e2e8f0',
    borderStyle: '1px solid #3d424b',
    shadowStyle: '5px 5px 10px #1e2024, -5px -5px 10px #30343c',
    borderRadius: '0.75rem',
    fontFamily: 'Space Grotesk',
    headingFont: 'Outfit'
  },
  'neumorphism': {
    id: 'neumorphism',
    name: 'Neumorphism',
    tagline: 'Soft-extruded minimal dual-shadow surfaces',
    description: 'Seamless monochromatic embossed surfaces that appear carved directly out of the background plane.',
    primaryColor: '#3b82f6',
    accentColor: '#0284c7',
    backgroundColor: '#e2e8f0',
    cardBackground: '#e2e8f0',
    textColor: '#1e293b',
    borderStyle: '1px solid rgba(255, 255, 255, 0.4)',
    shadowStyle: '10px 10px 20px #c1c5cc, -10px -10px 20px #ffffff',
    borderRadius: '1.5rem',
    fontFamily: 'Plus Jakarta Sans',
    headingFont: 'Plus Jakarta Sans'
  },
  'glassmorphism': {
    id: 'glassmorphism',
    name: 'Glassmorphism',
    tagline: 'Frosted refraction with vibrant ambient blur',
    description: 'Ultra-thin translucent layers floating over purple and indigo gradients with frosted glass edges.',
    primaryColor: '#8b5cf6',
    accentColor: '#ec4899',
    backgroundColor: '#0f172a',
    cardBackground: 'rgba(255, 255, 255, 0.08)',
    textColor: '#f8fafc',
    borderStyle: '1px solid rgba(255, 255, 255, 0.15)',
    shadowStyle: '0 8px 32px 0 rgba(0, 0, 0, 0.3)',
    borderRadius: '1rem',
    fontFamily: 'Plus Jakarta Sans',
    headingFont: 'Outfit'
  },
  'brutalism': {
    id: 'brutalism',
    name: 'Brutalism',
    tagline: 'High-contrast neo-brutalist poster styling',
    description: 'Zero corner radius, heavy 3px solid black borders, intense yellow canvas, and offset solid drop shadows.',
    primaryColor: '#000000',
    accentColor: '#f43f5e',
    backgroundColor: '#fde047',
    cardBackground: '#ffffff',
    textColor: '#000000',
    borderStyle: '3px solid #000000',
    shadowStyle: '5px 5px 0px #000000',
    borderRadius: '0px',
    fontFamily: 'Space Grotesk',
    headingFont: 'Space Grotesk'
  },
  'minimalism': {
    id: 'minimalism',
    name: 'Minimalism',
    tagline: 'Pure white editorial clarity with micro-lines',
    description: 'Zero visual noise, crisp typography, generous whitespace, razor-thin hairlines, and focus on pure readability.',
    primaryColor: '#0f172a',
    accentColor: '#475569',
    backgroundColor: '#ffffff',
    cardBackground: '#ffffff',
    textColor: '#0f172a',
    borderStyle: '1px solid #e2e8f0',
    shadowStyle: '0 1px 3px rgba(0,0,0,0.05)',
    borderRadius: '0.5rem',
    fontFamily: 'DM Sans',
    headingFont: 'Outfit'
  },
  'maximalism': {
    id: 'maximalism',
    name: 'Maximalism',
    tagline: 'Electric saturated neon purple with daring contrast',
    description: 'Rich royal purples, glowing golden yellows, high saturation and expressive borders for high energy.',
    primaryColor: '#f59e0b',
    accentColor: '#10b981',
    backgroundColor: '#2e1065',
    cardBackground: '#4c1d95',
    textColor: '#fdf4ff',
    borderStyle: '2px solid #f43f5e',
    shadowStyle: '0 15px 35px -5px rgba(244, 63, 94, 0.35)',
    borderRadius: '1.5rem',
    fontFamily: 'Outfit',
    headingFont: 'Outfit'
  },
  'bento-grid': {
    id: 'bento-grid',
    name: 'Bento Grid',
    tagline: 'Structured modular precision and metric tiles',
    description: 'Sleek dark rectangular compartments inspired by Apple and Japanese bento layouts for structured analytics.',
    primaryColor: '#38bdf8',
    accentColor: '#10b981',
    backgroundColor: '#0b0f17',
    cardBackground: '#111726',
    textColor: '#f1f5f9',
    borderStyle: '1px solid #1f293d',
    shadowStyle: '0 4px 20px -2px rgba(0, 0, 0, 0.5)',
    borderRadius: '1.25rem',
    fontFamily: 'Plus Jakarta Sans',
    headingFont: 'Outfit'
  },
  'spatial-ui': {
    id: 'spatial-ui',
    name: 'Spatial UI',
    tagline: 'Deep 3D spatial canvas with visionOS depth',
    description: 'Layered atmospheric planes, subtle indigo rim illumination, elevated depth, and futuristic spatial clarity.',
    primaryColor: '#6366f1',
    accentColor: '#a855f7',
    backgroundColor: '#030712',
    cardBackground: 'rgba(17, 24, 39, 0.5)',
    textColor: '#f8fafc',
    borderStyle: '1px solid rgba(99, 102, 241, 0.25)',
    shadowStyle: '0 20px 50px rgba(99, 102, 241, 0.15)',
    borderRadius: '1.75rem',
    fontFamily: 'Plus Jakarta Sans',
    headingFont: 'Outfit'
  }
};
