import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Star,
  Camera,
  Bell,
  FileSpreadsheet,
  ArrowRight,
  Sparkles,
  Lock,
  Megaphone,
  CheckCircle,
  Eye,
  Clock,
  HeartHandshake
} from 'lucide-react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { TodayMenu } from './components/TodayMenu';
import { FeedbackForm } from './components/FeedbackForm';
import { ComplaintTracker } from './components/ComplaintTracker';
import { AdminLoginModal } from './components/AdminLoginModal';
import { AdminDashboard } from './components/AdminDashboard';
import { AboutPrivacy } from './components/AboutPrivacy';
import { MenuItem, CookStaff, WebsiteSettings, WebsiteUpdate, MealCategory, ThemeName } from './types';
import { THEME_DEFINITIONS } from './themeConfig';

export default function App() {
  const [currentTab, setCurrentTab] = useState<'home' | 'menu' | 'feedback' | 'tracker' | 'about' | 'admin'>('home');
  const [settings, setSettings] = useState<WebsiteSettings | null>(null);
  const [menus, setMenus] = useState<MenuItem[]>([]);
  const [staffList, setStaffList] = useState<CookStaff[]>([]);
  const [updates, setUpdates] = useState<WebsiteUpdate[]>([]);
  const [userRatings, setUserRatings] = useState<Record<string, number>>({});
  const [feedbackCategory, setFeedbackCategory] = useState<MealCategory>('Lunch');
  const [trackerSearchId, setTrackerSearchId] = useState<string>('');

  // Admin Auth
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [adminToken, setAdminToken] = useState('');
  const [adminUsername, setAdminUsername] = useState('admin.complaint');
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

  // Theme preview modal
  const [isThemeQuickSwitchOpen, setIsThemeQuickSwitchOpen] = useState(false);

  // Student anonymous device token
  const getStudentToken = () => {
    let tok = localStorage.getItem('ha_student_token');
    if (!tok) {
      tok = 'st_' + Math.random().toString(36).substring(2, 12);
      localStorage.setItem('ha_student_token', tok);
    }
    return tok;
  };

  // Fetch initial configuration and data
  const fetchData = async () => {
    try {
      const [settingsRes, menuRes, staffRes, updatesRes] = await Promise.all([
        fetch('/api/settings'),
        fetch('/api/menu'),
        fetch('/api/staff'),
        fetch('/api/updates')
      ]);

      const settingsData = await settingsRes.json();
      if (settingsData.settings) setSettings(settingsData.settings);

      const menuData = await menuRes.json();
      if (menuData.menus) setMenus(menuData.menus);

      const staffData = await staffRes.json();
      if (staffData.staff) setStaffList(staffData.staff);

      const updatesData = await updatesRes.json();
      if (updatesData.updates) setUpdates(updatesData.updates);
    } catch (err) {
      console.error('Error fetching initial app data:', err);
    }
  };

  useEffect(() => {
    fetchData();

    // Check existing stored admin session
    const storedToken = sessionStorage.getItem('ha_admin_token');
    const storedUser = sessionStorage.getItem('ha_admin_user');
    if (storedToken) {
      setAdminToken(storedToken);
      setIsAdminLoggedIn(true);
      if (storedUser) setAdminUsername(storedUser);
    }

    // Load saved student ratings
    try {
      const localRatings = localStorage.getItem('ha_user_ratings');
      if (localRatings) setUserRatings(JSON.parse(localRatings));
    } catch (e) {
      // ignore
    }
  }, []);

  // Handle rating a meal
  const handleRateMeal = async (menuId: string, rating: number) => {
    const token = getStudentToken();
    try {
      const res = await fetch(`/api/menu/${menuId}/rate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rating, studentToken: token })
      });
      const data = await res.json();
      if (data.success) {
        const nextRatings = { ...userRatings, [menuId]: rating };
        setUserRatings(nextRatings);
        localStorage.setItem('ha_user_ratings', JSON.stringify(nextRatings));

        // Update menu list state
        setMenus((prev) =>
          prev.map((m) =>
            m.id === menuId
              ? {
                  ...m,
                  averageRating: data.averageRating,
                  totalRatings: data.totalRatings
                }
              : m
          )
        );
      }
    } catch (err) {
      console.error('Failed to submit meal rating:', err);
    }
  };

  const handleReportSpecificMeal = (category: MealCategory) => {
    setFeedbackCategory(category);
    setCurrentTab('feedback');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleTrackComplaint = (id: string) => {
    setTrackerSearchId(id);
    setCurrentTab('tracker');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAdminLoginSuccess = (token: string, username: string) => {
    setAdminToken(token);
    setAdminUsername(username);
    setIsAdminLoggedIn(true);
    sessionStorage.setItem('ha_admin_token', token);
    sessionStorage.setItem('ha_admin_user', username);
    setCurrentTab('admin');
  };

  const handleAdminLogout = () => {
    sessionStorage.removeItem('ha_admin_token');
    sessionStorage.removeItem('ha_admin_user');
    setAdminToken('');
    setIsAdminLoggedIn(false);
    setCurrentTab('home');
  };

  const activeThemeClass = settings?.activeTheme ? `theme-${settings.activeTheme}` : 'theme-liquid-glass';

  if (!settings) {
    return (
      <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center">
        <div className="text-center space-y-3">
          <div className="w-8 h-8 mx-auto border-2 border-blue-500/30 border-t-blue-500 rounded-full animate-spin" />
          <p className="text-xs text-slate-400">Loading HELP ANONYMOUS portal...</p>
        </div>
      </div>
    );
  }

  // If in admin mode, show the full admin dashboard
  if (currentTab === 'admin' && isAdminLoggedIn) {
    return (
      <div className={activeThemeClass}>
        <AdminDashboard
          adminToken={adminToken}
          username={adminUsername}
          onLogout={handleAdminLogout}
          onReturnToStudentHome={() => setCurrentTab('home')}
          settings={settings}
          onSettingsUpdated={(newSettings) => setSettings(newSettings)}
          menus={menus}
          staffList={staffList}
          onRefreshData={fetchData}
        />
      </div>
    );
  }

  return (
    <div className={`min-h-screen flex flex-col transition-colors ${activeThemeClass}`}>
      {/* Top Header */}
      <Header
        settings={settings}
        currentTab={currentTab}
        onSelectTab={(tab) => {
          setCurrentTab(tab as any);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        isAdminLoggedIn={isAdminLoggedIn}
        onOpenAdminLogin={() => setIsLoginModalOpen(true)}
        onOpenAdminDashboard={() => setCurrentTab('admin')}
        onOpenThemeQuickSwitch={() => setIsThemeQuickSwitchOpen(true)}
      />

      {/* Main Student Experience */}
      <main className="flex-1">
        {/* Active Announcement Banner if any */}
        {updates.length > 0 && updates[0].active && (
          <div className="bg-gradient-to-r from-blue-900/60 via-indigo-900/60 to-blue-900/60 border-b border-white/10 py-2.5 px-4 text-center text-xs">
            <span className="font-semibold text-sky-300">Notice: </span>
            <span className="text-slate-200">{updates[0].title}</span>
            <span className="hidden sm:inline text-slate-400"> — {updates[0].description}</span>
          </div>
        )}

        {/* 1. HOME TAB */}
        {currentTab === 'home' && (
          <div className="space-y-12">
            {/* Hero Section */}
            <section className="relative overflow-hidden pt-12 pb-16 lg:pt-20 lg:pb-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
                {/* Hero Text */}
                <div className="lg:col-span-7 space-y-6 text-left">
                  <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-sky-400/30 bg-sky-500/10 text-sky-300 text-xs font-semibold">
                    <ShieldCheck className="w-4 h-4 text-sky-400" />
                    <span>100% Student Anonymity Guaranteed</span>
                  </div>

                  <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-[1.15]">
                    {settings.heroHeading || 'Hostel Mess Rating & Anonymous Grievances'}
                  </h1>

                  <p className="text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed">
                    {settings.welcomeMessage ||
                      'Rate daily hostel meals, submit anonymous complaints with photo proof, and give constructive suggestions to help wardens audit food hygiene and kitchen staff behaviour.'}
                  </p>

                  <div className="pt-2 flex flex-wrap items-center gap-4">
                    <button
                      onClick={() => {
                        setCurrentTab('feedback');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className="py-3.5 px-6 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-sm shadow-xl hover:shadow-blue-500/25 transition-all flex items-center gap-2 cursor-pointer"
                    >
                      <span>Submit Anonymous Complaint</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => {
                        setCurrentTab('menu');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className="py-3.5 px-6 rounded-2xl border border-white/15 bg-white/5 hover:bg-white/10 text-white font-semibold text-sm transition-all cursor-pointer flex items-center gap-2"
                    >
                      <Star className="w-4 h-4 text-amber-400" />
                      <span>Rate Today's Food</span>
                    </button>

                    <button
                      onClick={() => {
                        setCurrentTab('tracker');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className="py-3.5 px-4 rounded-2xl text-slate-300 hover:text-white text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer underline underline-offset-4"
                    >
                      <span>Track Grievance</span>
                    </button>
                  </div>
                </div>

                {/* Hero Graphic / Photo Card */}
                <div className="lg:col-span-5 relative">
                  <div className="relative rounded-3xl overflow-hidden border border-white/15 bg-slate-900 shadow-2xl">
                    <img
                      src="/src/assets/images/hostel_mess_hall_hero_1793681503862.jpg"
                      alt="Hostel dining hall"
                      referrerPolicy="no-referrer"
                      className="w-full aspect-[4/3] object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />

                    <div className="absolute bottom-5 left-5 right-5 p-4 rounded-2xl bg-slate-900/80 backdrop-blur-md border border-white/10 space-y-1">
                      <div className="flex items-center justify-between text-xs font-bold text-white">
                        <span>Mess Quality Oversight</span>
                        <span className="text-emerald-400 font-mono">100% Whistleblower Shield</span>
                      </div>
                      <p className="text-[11px] text-slate-300">
                        Zero roll numbers, student names, or room numbers are ever displayed to hostel cooks or wardens.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* 4 Trust & Feature Pillars */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  {
                    icon: ShieldCheck,
                    title: '100% Student Privacy',
                    desc: 'No names, emails, roll numbers or IP addresses exposed to hostel staff.',
                    color: 'text-sky-400',
                    bg: 'bg-sky-500/10'
                  },
                  {
                    icon: Camera,
                    title: 'Photo Proof Upload',
                    desc: 'Attach JPG, PNG, WEBP photos of burnt rotis, undercooked rice or insects.',
                    color: 'text-emerald-400',
                    bg: 'bg-emerald-500/10'
                  },
                  {
                    icon: Bell,
                    title: 'Silent Open Alert',
                    desc: 'Track when the warden opens your complaint: "Your complaint has been opened."',
                    color: 'text-amber-400',
                    bg: 'bg-amber-500/10'
                  },
                  {
                    icon: FileSpreadsheet,
                    title: 'Weekly Warden Report',
                    desc: 'Scheduled automated reports with meal ratings, staff stats and recommendations.',
                    color: 'text-indigo-400',
                    bg: 'bg-indigo-500/10'
                  }
                ].map((col, idx) => {
                  const Icon = col.icon;
                  return (
                    <div
                      key={idx}
                      className="p-5 rounded-2xl border border-white/10 bg-slate-900/50 backdrop-blur-md space-y-2 hover:border-white/20 transition-colors"
                    >
                      <div className={`w-9 h-9 rounded-xl ${col.bg} ${col.color} flex items-center justify-center`}>
                        <Icon className="w-5 h-5" />
                      </div>
                      <h4 className="text-sm font-bold text-white">{col.title}</h4>
                      <p className="text-xs text-slate-400 leading-relaxed">{col.desc}</p>
                    </div>
                  );
                })}
              </div>
            </section>

            {/* Today's Mess Menu Section */}
            <TodayMenu
              menus={menus}
              onRate={handleRateMeal}
              userRatings={userRatings}
              onReportMeal={handleReportSpecificMeal}
            />

            {/* Anonymous Complaint Action CTA Banner */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
              <div className="rounded-3xl border border-white/10 bg-gradient-to-r from-blue-950/60 via-slate-900/70 to-indigo-950/60 backdrop-blur-xl p-8 sm:p-12 flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl">
                <div className="space-y-2 max-w-xl">
                  <span className="text-xs font-semibold uppercase tracking-wider text-sky-400">
                    Mess Hall Feedback
                  </span>
                  <h3 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
                    Faced Misbehaviour or Poor Quality Food?
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                    Submit your grievance directly with photo proof. If the cook ignored or misbehaved with you, state it clearly in our conditional feedback questionnaire.
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row items-center gap-3 shrink-0">
                  <button
                    onClick={() => {
                      setCurrentTab('feedback');
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="py-3.5 px-6 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs transition-colors cursor-pointer"
                  >
                    Open Anonymous Feedback Form
                  </button>
                  <button
                    onClick={() => {
                      setCurrentTab('tracker');
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="py-3.5 px-6 rounded-2xl border border-white/15 bg-white/5 hover:bg-white/10 text-white font-semibold text-xs transition-colors cursor-pointer"
                  >
                    Track Existing Grievance
                  </button>
                </div>
              </div>
            </section>
          </div>
        )}

        {/* 2. MENU TAB */}
        {currentTab === 'menu' && (
          <TodayMenu
            menus={menus}
            onRate={handleRateMeal}
            userRatings={userRatings}
            onReportMeal={handleReportSpecificMeal}
          />
        )}

        {/* 3. FEEDBACK FORM TAB */}
        {currentTab === 'feedback' && (
          <FeedbackForm
            staffList={staffList}
            initialCategory={feedbackCategory}
            onTrackComplaint={handleTrackComplaint}
          />
        )}

        {/* 4. TRACKER TAB */}
        {currentTab === 'tracker' && (
          <ComplaintTracker
            initialSearchId={trackerSearchId}
            onNavigateFeedback={() => {
              setCurrentTab('feedback');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {/* 5. PRIVACY POLICY & ABOUT TAB */}
        {currentTab === 'about' && (
          <AboutPrivacy
            settings={settings}
            onNavigateFeedback={() => {
              setCurrentTab('feedback');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}
      </main>

      {/* Footer */}
      <Footer
        settings={settings}
        onSelectTab={(tab) => {
          setCurrentTab(tab as any);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenAdminLogin={() => setIsLoginModalOpen(true)}
      />

      {/* Admin Login Modal */}
      <AdminLoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        onLoginSuccess={handleAdminLoginSuccess}
      />

      {/* Quick Theme Switcher Modal */}
      {isThemeQuickSwitchOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="w-full max-w-2xl max-h-[85vh] overflow-y-auto rounded-3xl border border-white/10 bg-slate-900 p-6 sm:p-8 space-y-5 shadow-2xl relative">
            <button
              onClick={() => setIsThemeQuickSwitchOpen(false)}
              className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-white"
            >
              ✕
            </button>
            <div className="space-y-1">
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-sky-400" />
                Select One of 10 Website Themes
              </h3>
              <p className="text-xs text-slate-400">
                Experience HELP ANONYMOUS in 10 unique visual paradigms:
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              {Object.values(THEME_DEFINITIONS).map((t) => {
                const isActive = settings.activeTheme === t.id;
                return (
                  <button
                    key={t.id}
                    onClick={() => {
                      setSettings({ ...settings, activeTheme: t.id });
                      setIsThemeQuickSwitchOpen(false);
                    }}
                    className={`p-4 rounded-2xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                      isActive
                        ? 'border-sky-400 bg-sky-950/40 ring-1 ring-sky-400'
                        : 'border-white/10 bg-slate-800/60 hover:bg-slate-800 hover:border-white/20'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-bold text-white">{t.name}</span>
                        {isActive && <span className="text-[10px] text-sky-300 font-bold">Active</span>}
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1 line-clamp-2">{t.description}</p>
                    </div>
                    <div className="flex items-center gap-2 mt-3 text-[10px] font-mono text-slate-400">
                      <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: t.primaryColor }} />
                      <span>{t.fontFamily}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
