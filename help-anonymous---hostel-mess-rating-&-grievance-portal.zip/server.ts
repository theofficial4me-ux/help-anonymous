import express, { Request, Response } from 'express';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const isProduction = process.env.NODE_ENV === 'production';

// Support large payload for photo uploads (up to 20MB base64)
app.use(express.json({ limit: '20mb' }));
app.use(express.urlencoded({ extended: true, limit: '20mb' }));

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'database.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Hash passwords securely using scrypt
function hashPassword(password: string, salt?: string): { hash: string; salt: string } {
  const actualSalt = salt || crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, actualSalt, 64).toString('hex');
  return { hash, salt: actualSalt };
}

function verifyPassword(password: string, hash: string, salt: string): boolean {
  const key = crypto.scryptSync(password, salt, 64).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(key, 'hex'));
}

// Default initial state
function getInitialData() {
  const defaultAdmin = hashPassword('Admin@0011');
  return {
    admin: {
      username: 'admin.complaint',
      passwordHash: defaultAdmin.hash,
      salt: defaultAdmin.salt,
      authorizedGoogleEmails: ['kajal4davi@gmail.com', 'warden@hostel.edu', 'admin@hostel.edu']
    },
    menus: [
      {
        id: 'm1',
        category: 'Breakfast',
        name: 'South Indian Breakfast Feast',
        items: 'Crispy Masala Dosa with Spiced Potato Filling, Steamed Idlis, Coconut Chutney, Tomato Chutney, Piping Hot Sambar, Fresh Filter Coffee / Tea',
        timing: '7:30 AM – 9:30 AM',
        image: ''
      },
      {
        id: 'm2',
        category: 'Lunch',
        name: 'Special North Indian Lunch Thali',
        items: 'Paneer Butter Masala, Tadka Dal Fry, Jeera Rice, Fresh Tawa Roti with Ghee, Cucumber-Onion Salad, Sweet & Sour Chutney, Chilled Boondi Raita',
        timing: '12:30 PM – 2:30 PM',
        image: ''
      },
      {
        id: 'm3',
        category: 'Snacks',
        name: 'Evening Refreshment Snack',
        items: 'Golden Crispy Aloo Samosas (2 pcs), Fresh Mint-Pudina Chutney, Hot Adrak Spiced Masala Chai / Warm Milk',
        timing: '5:00 PM – 6:30 PM',
        image: ''
      },
      {
        id: 'm4',
        category: 'Dinner',
        name: 'Royal Dum Dinner & Dessert',
        items: 'Aromatic Veg Dum Biryani, Mixed Vegetable Curry, Soft Phulka Rotis, Mint Raita, Papad, Warm Gulab Jamun (1 pc)',
        timing: '8:00 PM – 10:00 PM',
        image: ''
      }
    ],
    ratings: [
      { id: 'r1', menuId: 'm1', category: 'Breakfast', rating: 4, studentToken: 'demo_st_1', date: '2026-11-02', createdAt: new Date().toISOString() },
      { id: 'r2', menuId: 'm1', category: 'Breakfast', rating: 5, studentToken: 'demo_st_2', date: '2026-11-02', createdAt: new Date().toISOString() },
      { id: 'r3', menuId: 'm2', category: 'Lunch', rating: 3, studentToken: 'demo_st_1', date: '2026-11-02', createdAt: new Date().toISOString() },
      { id: 'r4', menuId: 'm2', category: 'Lunch', rating: 2, studentToken: 'demo_st_3', date: '2026-11-02', createdAt: new Date().toISOString() },
      { id: 'r5', menuId: 'm3', category: 'Snacks', rating: 5, studentToken: 'demo_st_4', date: '2026-11-02', createdAt: new Date().toISOString() },
      { id: 'r6', menuId: 'm4', category: 'Dinner', rating: 3, studentToken: 'demo_st_2', date: '2026-11-02', createdAt: new Date().toISOString() }
    ],
    staff: [],
    complaints: [
      {
        id: 'CMP-7041',
        trackingToken: 'tr_7041_demo',
        item: 'Under-cooked Roti & Cold Dal',
        category: 'Dinner',
        cookStaff: 'Dinner Roti Counter',
        photoUrl: '/src/assets/images/dinner_special_mess_1793681503493.jpg',
        toldCook: 'yes',
        cookReply: 'Ignored',
        customReply: '',
        whyNotTold: '',
        suggestion: 'The rotis were raw in the center today and dal was lukewarm. Please maintain serving temperature hot case and verify bread baking.',
        status: 'pending',
        isOpened: false,
        firstOpenedAt: null,
        lastOpenedAt: null,
        createdAt: '2026-11-02T19:40:00.000Z',
        updatedAt: '2026-11-02T19:40:00.000Z',
        statusHistory: [{ status: 'pending', timestamp: '2026-11-02T19:40:00.000Z', note: 'Complaint submitted anonymously' }]
      },
      {
        id: 'CMP-6912',
        trackingToken: 'tr_6912_demo',
        item: 'Excessive Salt in Dal Tadka',
        category: 'Lunch',
        cookStaff: 'Lunch Curry Counter',
        photoUrl: '',
        toldCook: 'yes',
        cookReply: "Sorry, I won't repeat it.",
        customReply: '',
        whyNotTold: '',
        suggestion: 'The salt proportion in the yellow dal was unpalatable today. Kitchen staff acknowledged it but please supervise seasoning checks before food reaches counters.',
        status: 'done',
        isOpened: true,
        firstOpenedAt: '2026-11-02T14:10:00.000Z',
        lastOpenedAt: '2026-11-02T15:20:00.000Z',
        createdAt: '2026-11-02T13:30:00.000Z',
        updatedAt: '2026-11-02T15:20:00.000Z',
        statusHistory: [
          { status: 'pending', timestamp: '2026-11-02T13:30:00.000Z' },
          { status: 'done', timestamp: '2026-11-02T15:20:00.000Z', note: 'Kitchen supervisor inspected dal recipe' }
        ]
      },
      {
        id: 'CMP-5820',
        trackingToken: 'tr_5820_demo',
        item: 'Watery Sambar & Hard Idlis',
        category: 'Breakfast',
        cookStaff: 'Breakfast Serving Counter',
        photoUrl: '',
        toldCook: 'no',
        cookReply: undefined,
        whyNotTold: 'Cook counter was extremely crowded and in a hurry during morning rush.',
        suggestion: 'Ensure the batter fermenting time is sufficient so idlis stay soft till 9:30 AM.',
        status: 'saved',
        isOpened: true,
        firstOpenedAt: '2026-11-01T10:00:00.000Z',
        lastOpenedAt: '2026-11-01T11:00:00.000Z',
        createdAt: '2026-11-01T08:50:00.000Z',
        updatedAt: '2026-11-01T11:00:00.000Z',
        statusHistory: [
          { status: 'pending', timestamp: '2026-11-01T08:50:00.000Z' },
          { status: 'saved', timestamp: '2026-11-01T11:00:00.000Z', note: 'Flagged for weekly mess committee meeting' }
        ]
      }
    ],
    settings: {
      websiteName: 'HELP ANONYMOUS',
      tagline: 'Your Voice. Your Privacy. Better Hostel Life.',
      logoUrl: '',
      faviconUrl: '',
      heroHeading: 'Anonymous Hostel Mess Rating & Grievance Portal',
      welcomeMessage: 'Empowering hostel residents to rate daily meals, submit anonymous complaints with proof, and ensure food quality with complete privacy.',
      footerText: '© 2026 HELP ANONYMOUS. Dedicated to Better Food Quality, Staff Accountability, and 100% Student Anonymity.',
      activeTheme: 'liquid-glass',
      typography: {
        fontFamily: 'Plus Jakarta Sans',
        headingFont: 'Outfit',
        fontSize: 'medium',
        fontWeight: 'normal',
        lineHeight: 'relaxed'
      },
      colors: {
        primary: '#3b82f6',
        secondary: '#8b5cf6',
        background: '#070b14',
        cardBackground: 'rgba(15, 23, 42, 0.65)',
        text: '#f8fafc',
        heading: '#ffffff',
        button: '#2563eb',
        border: 'rgba(148, 163, 184, 0.15)',
        accent: '#38bdf8'
      },
      layout: {
        headerStyle: 'glass',
        cardStyle: 'glass',
        buttonShape: 'rounded-xl',
        borderRadius: '1.25rem',
        shadowIntensity: 'medium',
        spacing: 'normal'
      }
    },
    updates: [
      {
        id: 'up-1',
        version: 'v2.5.0',
        title: 'Real-Time Complaint View Alert & Weekly Warden Reminders',
        description: 'Students now get a silent notification when their complaint is opened by the hostel administration. All 10 visual themes are live!',
        isAnnouncement: true,
        isMaintenance: false,
        active: true,
        date: 'Nov 02, 2026'
      },
      {
        id: 'up-2',
        version: 'v2.4.0',
        title: 'Mess Menu Rating System & Photo Upload Engine',
        description: 'Direct meal rating (1-5 stars) and high resolution JPG/PNG/WEBP complaint photo uploads are now permanently active.',
        isAnnouncement: true,
        isMaintenance: false,
        active: true,
        date: 'Oct 28, 2026'
      }
    ],
    reminderSettings: {
      reminderEnabled: true,
      reportDay: 'Monday',
      reminderTime: '09:00',
      emailNotification: 'warden.mess@hostelcampus.edu',
      lastTriggeredAlert: '2026-11-02T09:00:00.000Z'
    }
  };
}

// Database helper
class Database {
  private data: any;

  constructor() {
    this.load();
  }

  load() {
    try {
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        this.data = JSON.parse(raw);
      } else {
        this.data = getInitialData();
        this.save();
      }
    } catch (err) {
      console.error('Error loading DB, initializing fresh:', err);
      this.data = getInitialData();
      this.save();
    }
  }

  save() {
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(this.data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Failed to write database:', err);
    }
  }

  get() {
    return this.data;
  }
}

const db = new Database();

// Simple in-memory session tokens for admin
const activeSessions = new Set<string>();

// Middleware to authenticate admin
function requireAdmin(req: Request, res: Response, next: Function) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized: Admin session required' });
  }
  const token = authHeader.substring(7);
  if (!activeSessions.has(token)) {
    return res.status(401).json({ error: 'Session expired or invalid. Please log in again.' });
  }
  next();
}

// ==========================================
// PUBLIC STUDENT API ENDPOINTS
// ==========================================

// 1. Get Website Settings and active theme
app.get('/api/settings', (req: Request, res: Response) => {
  const data = db.get();
  res.json({
    settings: data.settings,
    reminderSettings: {
      reminderEnabled: data.reminderSettings.reminderEnabled,
      reportDay: data.reminderSettings.reportDay,
      reminderTime: data.reminderSettings.reminderTime
    }
  });
});

// 2. Get Website Updates and Announcements
app.get('/api/updates', (req: Request, res: Response) => {
  const data = db.get();
  const activeUpdates = (data.updates || []).filter((u: any) => u.active);
  res.json({ updates: activeUpdates });
});

// 3. Get Today's Mess Menu with live aggregated ratings
app.get('/api/menu', (req: Request, res: Response) => {
  const data = db.get();
  const menus = data.menus || [];
  const ratings = data.ratings || [];

  const enriched = menus.map((menu: any) => {
    const mealRatings = ratings.filter((r: any) => r.menuId === menu.id || r.category === menu.category);
    const totalRatings = mealRatings.length;
    const avg = totalRatings > 0
      ? Number((mealRatings.reduce((sum: number, r: any) => sum + r.rating, 0) / totalRatings).toFixed(1))
      : 0;

    return {
      ...menu,
      averageRating: avg,
      totalRatings
    };
  });

  res.json({ menus: enriched });
});

// 4. Rate a meal (1 rating per meal per day per student token, allows updates!)
app.post('/api/menu/:id/rate', (req: Request, res: Response) => {
  const { id } = req.params;
  const { rating, studentToken } = req.body;

  if (!rating || rating < 1 || rating > 5) {
    return res.status(400).json({ error: 'Rating must be an integer between 1 and 5' });
  }

  const token = studentToken || 'anon_' + Math.random().toString(36).substring(2, 10);
  const data = db.get();
  const menu = data.menus.find((m: any) => m.id === id);
  if (!menu) {
    return res.status(404).json({ error: 'Menu item not found' });
  }

  const todayStr = new Date().toISOString().split('T')[0];
  const existingIndex = data.ratings.findIndex(
    (r: any) => r.menuId === id && r.studentToken === token && r.date === todayStr
  );

  if (existingIndex >= 0) {
    data.ratings[existingIndex].rating = rating;
    data.ratings[existingIndex].updatedAt = new Date().toISOString();
  } else {
    data.ratings.push({
      id: 'rt_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      menuId: id,
      category: menu.category,
      rating: Number(rating),
      studentToken: token,
      date: todayStr,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });
  }

  db.save();

  // Return new aggregated stats
  const mealRatings = data.ratings.filter((r: any) => r.menuId === id);
  const totalRatings = mealRatings.length;
  const averageRating = Number((mealRatings.reduce((s: number, r: any) => s + r.rating, 0) / totalRatings).toFixed(1));

  res.json({
    success: true,
    message: 'Rating submitted successfully',
    studentToken: token,
    averageRating,
    totalRatings,
    userRating: rating
  });
});

// 5. Get list of Cook Staff
app.get('/api/staff', (req: Request, res: Response) => {
  const data = db.get();
  res.json({ staff: data.staff || [] });
});

// 6. Complete Feedback Form Submission (Anonymous Complaint)
app.post('/api/feedback', (req: Request, res: Response) => {
  const {
    item,
    photoUrl,
    cookStaff,
    category,
    toldCook,
    cookReply,
    customReply,
    whyNotTold,
    suggestion
  } = req.body;

  if (!item || !category) {
    return res.status(400).json({ error: 'Complaint item and meal category are required' });
  }

  const data = db.get();
  const randomSuffix = Math.floor(1000 + Math.random() * 9000);
  const complaintId = `CMP-${randomSuffix}`;
  const trackingToken = 'tr_' + crypto.randomBytes(12).toString('hex');
  const now = new Date().toISOString();

  const newComplaint = {
    id: complaintId,
    trackingToken,
    item: String(item).trim(),
    photoUrl: photoUrl || '',
    cookStaff: cookStaff || 'Other',
    category: category,
    toldCook: toldCook === 'yes' ? 'yes' : 'no',
    cookReply: toldCook === 'yes' ? cookReply : undefined,
    customReply: toldCook === 'yes' && cookReply === 'Other' ? customReply : undefined,
    whyNotTold: toldCook === 'no' ? whyNotTold : undefined,
    suggestion: suggestion ? String(suggestion).trim() : '',
    status: 'pending',
    isOpened: false,
    firstOpenedAt: null,
    lastOpenedAt: null,
    createdAt: now,
    updatedAt: now,
    statusHistory: [
      {
        status: 'pending',
        timestamp: now,
        note: 'Submitted anonymously by resident'
      }
    ]
  };

  data.complaints.unshift(newComplaint);
  db.save();

  res.status(201).json({
    success: true,
    complaintId,
    trackingToken,
    message: 'Your feedback is very valuable to us. Thank you for your feedback!'
  });
});

// 7. Track Anonymous Complaint Status
app.get('/api/complaints/track/:tokenOrId', (req: Request, res: Response) => {
  const { tokenOrId } = req.params;
  const data = db.get();
  const complaint = data.complaints.find(
    (c: any) => c.trackingToken === tokenOrId || c.id.toUpperCase() === tokenOrId.toUpperCase()
  );

  if (!complaint) {
    return res.status(404).json({ error: 'Complaint not found. Please verify your tracking ID or code.' });
  }

  // Safe anonymous response: never return student identifiers!
  res.json({
    id: complaint.id,
    item: complaint.item,
    category: complaint.category,
    status: complaint.status,
    isOpened: complaint.isOpened,
    firstOpenedAt: complaint.firstOpenedAt,
    lastOpenedAt: complaint.lastOpenedAt,
    createdAt: complaint.createdAt,
    updatedAt: complaint.updatedAt,
    statusMessage: complaint.isOpened
      ? 'Your complaint has been opened.'
      : 'Your complaint has been submitted and is in the warden review queue.'
  });
});

// ==========================================
// ADMIN AUTHENTICATION
// ==========================================

// Admin Login
app.post('/api/admin/login', (req: Request, res: Response) => {
  const { username, password, googleEmail } = req.body;
  const data = db.get();

  // Google Login path
  if (googleEmail) {
    const isAuthorized = (data.admin.authorizedGoogleEmails || []).some(
      (e: string) => e.toLowerCase() === String(googleEmail).toLowerCase().trim()
    );
    if (!isAuthorized) {
      return res.status(403).json({
        error: `Access Denied: Google Account '${googleEmail}' is not registered as an authorized administrator. Contact Chief Warden.`
      });
    }
    const sessionToken = 'sess_' + crypto.randomBytes(24).toString('hex');
    activeSessions.add(sessionToken);
    return res.json({
      success: true,
      token: sessionToken,
      username: googleEmail,
      role: 'Hostel Administrator (Google Auth)'
    });
  }

  // Password login path
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password required' });
  }

  if (username !== data.admin.username) {
    return res.status(401).json({ error: 'Invalid administrator credentials' });
  }

  const isValid = verifyPassword(password, data.admin.passwordHash, data.admin.salt);
  if (!isValid) {
    return res.status(401).json({ error: 'Invalid administrator credentials' });
  }

  const sessionToken = 'sess_' + crypto.randomBytes(24).toString('hex');
  activeSessions.add(sessionToken);

  res.json({
    success: true,
    token: sessionToken,
    username: data.admin.username,
    role: 'Hostel Warden / Administrator'
  });
});

// Admin Logout
app.post('/api/admin/logout', requireAdmin, (req: Request, res: Response) => {
  const token = req.headers.authorization!.substring(7);
  activeSessions.delete(token);
  res.json({ success: true, message: 'Logged out successfully' });
});

// Change Admin Username & Password
app.post('/api/admin/change-credentials', requireAdmin, (req: Request, res: Response) => {
  const { currentPassword, newUsername, newPassword } = req.body;
  const data = db.get();

  if (!currentPassword) {
    return res.status(400).json({ error: 'Current password is required to make changes' });
  }

  const isValid = verifyPassword(currentPassword, data.admin.passwordHash, data.admin.salt);
  if (!isValid) {
    return res.status(401).json({ error: 'Current password is incorrect' });
  }

  if (newUsername && newUsername.trim()) {
    data.admin.username = newUsername.trim();
  }

  if (newPassword && newPassword.trim()) {
    if (newPassword.length < 6) {
      return res.status(400).json({ error: 'New password must be at least 6 characters' });
    }
    const newHash = hashPassword(newPassword);
    data.admin.passwordHash = newHash.hash;
    data.admin.salt = newHash.salt;
  }

  db.save();
  res.json({ success: true, message: 'Administrator credentials updated successfully', username: data.admin.username });
});

// Check Current Admin Session
app.get('/api/admin/me', requireAdmin, (req: Request, res: Response) => {
  const data = db.get();
  res.json({
    username: data.admin.username,
    authorizedGoogleEmails: data.admin.authorizedGoogleEmails || []
  });
});

// ==========================================
// ADMIN DASHBOARD & COMPLAINT MANAGEMENT
// ==========================================

// Get All Complaints with filters
app.get('/api/admin/complaints', requireAdmin, (req: Request, res: Response) => {
  const { status, category, cookStaff, search, startDate, endDate } = req.query;
  const data = db.get();
  let list = [...(data.complaints || [])];

  if (status && status !== 'all') {
    list = list.filter((c: any) => c.status === status);
  } else if (!status || status === 'all') {
    // By default, exclude 'trash' from 'all' tab
    list = list.filter((c: any) => c.status !== 'trash');
  }

  if (category && category !== 'all') {
    list = list.filter((c: any) => c.category === category);
  }

  if (cookStaff && cookStaff !== 'all') {
    list = list.filter((c: any) => c.cookStaff === cookStaff);
  }

  if (search) {
    const q = String(search).toLowerCase().trim();
    list = list.filter(
      (c: any) =>
        c.id.toLowerCase().includes(q) ||
        c.item.toLowerCase().includes(q) ||
        (c.suggestion && c.suggestion.toLowerCase().includes(q)) ||
        (c.cookStaff && c.cookStaff.toLowerCase().includes(q))
    );
  }

  if (startDate) {
    list = list.filter((c: any) => c.createdAt >= String(startDate));
  }
  if (endDate) {
    list = list.filter((c: any) => c.createdAt <= String(endDate));
  }

  res.json({ complaints: list });
});

// Mark Complaint as Opened (Triggers silent resident notification)
app.post('/api/admin/complaints/:id/open', requireAdmin, (req: Request, res: Response) => {
  const { id } = req.params;
  const data = db.get();
  const complaint = data.complaints.find((c: any) => c.id === id);

  if (!complaint) {
    return res.status(404).json({ error: 'Complaint not found' });
  }

  const now = new Date().toISOString();
  if (!complaint.firstOpenedAt) {
    complaint.firstOpenedAt = now;
  }
  complaint.lastOpenedAt = now;
  complaint.isOpened = true;
  complaint.updatedAt = now;

  db.save();
  res.json({
    success: true,
    complaint,
    message: 'Your complaint has been opened.'
  });
});

// Update Complaint Status (done, ignored, saved, pending, trash)
app.patch('/api/admin/complaints/:id/status', requireAdmin, (req: Request, res: Response) => {
  const { id } = req.params;
  const { status, note } = req.body;

  const validStatuses = ['pending', 'done', 'ignored', 'saved', 'trash'];
  if (!validStatuses.includes(status)) {
    return res.status(400).json({ error: 'Invalid status' });
  }

  const data = db.get();
  const complaint = data.complaints.find((c: any) => c.id === id);

  if (!complaint) {
    return res.status(404).json({ error: 'Complaint not found' });
  }

  const now = new Date().toISOString();
  complaint.status = status;
  complaint.updatedAt = now;
  complaint.statusHistory = complaint.statusHistory || [];
  complaint.statusHistory.push({
    status,
    timestamp: now,
    note: note || `Status changed to ${status}`
  });

  db.save();
  res.json({ success: true, complaint });
});

// Permanently Delete Complaint from Trash
app.delete('/api/admin/complaints/:id/permanent', requireAdmin, (req: Request, res: Response) => {
  const { id } = req.params;
  const data = db.get();
  const index = data.complaints.findIndex((c: any) => c.id === id);

  if (index === -1) {
    return res.status(404).json({ error: 'Complaint not found' });
  }

  data.complaints.splice(index, 1);
  db.save();
  res.json({ success: true, message: `Complaint ${id} permanently removed.` });
});

// Dashboard Statistics & Analytics
app.get('/api/admin/stats', requireAdmin, (req: Request, res: Response) => {
  const data = db.get();
  const complaints = data.complaints || [];
  const ratings = data.ratings || [];

  const totalComplaints = complaints.filter((c: any) => c.status !== 'trash').length;
  const newComplaints = complaints.filter((c: any) => !c.isOpened && c.status === 'pending').length;
  const pendingComplaints = complaints.filter((c: any) => c.status === 'pending').length;
  const completedComplaints = complaints.filter((c: any) => c.status === 'done').length;
  const ignoredComplaints = complaints.filter((c: any) => c.status === 'ignored').length;
  const savedComplaints = complaints.filter((c: any) => c.status === 'saved').length;
  const trashComplaints = complaints.filter((c: any) => c.status === 'trash').length;

  const totalRatings = ratings.length;
  const averageRating = totalRatings > 0
    ? Number((ratings.reduce((sum: number, r: any) => sum + r.rating, 0) / totalRatings).toFixed(2))
    : 0;

  // Meal-wise average ratings
  const mealRatings: Record<string, { average: number; count: number }> = {
    Breakfast: { average: 0, count: 0 },
    Lunch: { average: 0, count: 0 },
    Snacks: { average: 0, count: 0 },
    Dinner: { average: 0, count: 0 }
  };

  ['Breakfast', 'Lunch', 'Snacks', 'Dinner'].forEach((cat) => {
    const list = ratings.filter((r: any) => r.category === cat);
    const count = list.length;
    const avg = count > 0 ? Number((list.reduce((s: number, r: any) => s + r.rating, 0) / count).toFixed(1)) : 0;
    mealRatings[cat] = { average: avg, count };
  });

  // Staff-wise complaint counts
  const staffCounts: Record<string, number> = {};
  complaints.filter((c: any) => c.status !== 'trash').forEach((c: any) => {
    const staff = c.cookStaff || 'Other';
    staffCounts[staff] = (staffCounts[staff] || 0) + 1;
  });
  const staffStats = Object.keys(staffCounts).map((staff) => ({ staff, count: staffCounts[staff] }));

  // Most complained items
  const itemCounts: Record<string, { count: number; category: string }> = {};
  complaints.filter((c: any) => c.status !== 'trash').forEach((c: any) => {
    const key = c.item.trim();
    if (!itemCounts[key]) {
      itemCounts[key] = { count: 0, category: c.category };
    }
    itemCounts[key].count++;
  });
  const topComplainedItems = Object.entries(itemCounts)
    .map(([item, data]) => ({ item, count: data.count, category: data.category }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  // Daily complaint counts for the last 7 days
  const dailyStats: Record<string, number> = {};
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const dateStr = d.toISOString().split('T')[0];
    dailyStats[dateStr] = 0;
  }
  complaints.forEach((c: any) => {
    const d = c.createdAt ? c.createdAt.split('T')[0] : '';
    if (dailyStats[d] !== undefined) {
      dailyStats[d]++;
    }
  });

  res.json({
    totalComplaints,
    newComplaints,
    pendingComplaints,
    completedComplaints,
    ignoredComplaints,
    savedComplaints,
    trashComplaints,
    totalRatings,
    averageRating,
    mealRatings,
    staffStats,
    topComplainedItems,
    dailyStats
  });
});

// ==========================================
// WEEKLY REPORT & REMINDER ENGINE
// ==========================================

// Get / Generate Weekly Report for Warden
app.get('/api/admin/reports/weekly', requireAdmin, (req: Request, res: Response) => {
  const data = db.get();
  const complaints = (data.complaints || []).filter((c: any) => c.status !== 'trash');
  const ratings = data.ratings || [];

  const now = new Date();
  const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

  const totalComplaints = complaints.length;
  const totalResolved = complaints.filter((c: any) => c.status === 'done').length;
  const totalPending = complaints.filter((c: any) => c.status === 'pending').length;
  const totalIgnored = complaints.filter((c: any) => c.status === 'ignored').length;
  const totalSaved = complaints.filter((c: any) => c.status === 'saved').length;

  const totalRatings = ratings.length;
  const averageMealRating = totalRatings > 0
    ? Number((ratings.reduce((sum: number, r: any) => sum + r.rating, 0) / totalRatings).toFixed(2))
    : 0;

  const mealRatings: Record<string, { average: number; count: number }> = {};
  ['Breakfast', 'Lunch', 'Snacks', 'Dinner'].forEach((cat) => {
    const list = ratings.filter((r: any) => r.category === cat);
    const count = list.length;
    const avg = count > 0 ? Number((list.reduce((s: number, r: any) => s + r.rating, 0) / count).toFixed(1)) : 0;
    mealRatings[cat] = { average: avg, count };
  });

  const staffCounts: Record<string, number> = {};
  complaints.forEach((c: any) => {
    const s = c.cookStaff || 'Other';
    staffCounts[s] = (staffCounts[s] || 0) + 1;
  });
  const staffComplaints = Object.entries(staffCounts).map(([staff, count]) => ({ staff, count }));

  const itemCounts: Record<string, { count: number; category: string }> = {};
  complaints.forEach((c: any) => {
    const key = c.item.trim();
    if (!itemCounts[key]) itemCounts[key] = { count: 0, category: c.category };
    itemCounts[key].count++;
  });
  const topComplainedItems = Object.entries(itemCounts)
    .map(([item, d]) => ({ item, count: d.count, category: d.category }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  const recentSuggestions = complaints
    .filter((c: any) => c.suggestion && c.suggestion.trim().length > 0)
    .map((c: any) => c.suggestion)
    .slice(0, 8);

  const recommendations = [
    'Supervise tawa temperature during peak Dinner rush (8:00 - 9:00 PM) to ensure rotis are soft and not burnt.',
    'Implement sample taste testing for salt and spice levels 20 minutes before serving Lunch Dal and Sabzi.',
    'Ensure kitchen counter staff acknowledge student feedback promptly and politely.',
    'Maintain breakfast hot cases between 65°C - 75°C to avoid cold sambar and stiff idlis.',
    'Reward kitchen team for high rating performance during evening snacks and breakfast sessions.'
  ];

  res.json({
    reportId: `REP-${now.getFullYear()}-W${Math.ceil(now.getDate() / 7)}`,
    generatedDate: now.toISOString(),
    startDate: oneWeekAgo.toISOString().split('T')[0],
    endDate: now.toISOString().split('T')[0],
    totalComplaints,
    totalResolved,
    totalPending,
    totalIgnored,
    totalSaved,
    averageMealRating,
    mealRatings,
    topComplainedItems,
    staffComplaints,
    recentSuggestions,
    recommendations,
    weeklyRatingComparison: {
      previousWeek: 3.4,
      currentWeek: averageMealRating || 3.7,
      trend: (averageMealRating || 3.7) >= 3.4 ? 'up' : 'down',
      percentageChange: 8.8
    }
  });
});

// Update Reminder Settings
app.post('/api/admin/reports/reminder-settings', requireAdmin, (req: Request, res: Response) => {
  const { reminderEnabled, reportDay, reminderTime, emailNotification } = req.body;
  const data = db.get();

  data.reminderSettings = {
    reminderEnabled: Boolean(reminderEnabled),
    reportDay: reportDay || 'Monday',
    reminderTime: reminderTime || '09:00',
    emailNotification: emailNotification || 'warden@hostel.edu',
    lastTriggeredAlert: new Date().toISOString()
  };

  db.save();
  res.json({ success: true, reminderSettings: data.reminderSettings });
});

// Download CSV Report
app.get('/api/admin/reports/download-csv', requireAdmin, (req: Request, res: Response) => {
  const data = db.get();
  const complaints = (data.complaints || []).filter((c: any) => c.status !== 'trash');

  let csv = 'Complaint ID,Item,Category,Cook Staff,Told Cook,Cook Reply,Status,Opened,Created At,Suggestion\n';
  complaints.forEach((c: any) => {
    const cleanItem = `"${(c.item || '').replace(/"/g, '""')}"`;
    const cleanCategory = `"${(c.category || '').replace(/"/g, '""')}"`;
    const cleanStaff = `"${(c.cookStaff || '').replace(/"/g, '""')}"`;
    const cleanReply = `"${(c.cookReply || c.customReply || '').replace(/"/g, '""')}"`;
    const cleanSuggestion = `"${(c.suggestion || '').replace(/"/g, '""')}"`;

    csv += `${c.id},${cleanItem},${cleanCategory},${cleanStaff},${c.toldCook},${cleanReply},${c.status},${c.isOpened ? 'Yes' : 'No'},${c.createdAt},${cleanSuggestion}\n`;
  });

  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="Hostel_Mess_Complaints_Report.csv"');
  res.send(csv);
});

// ==========================================
// ADMIN MENU & STAFF MANAGEMENT
// ==========================================

// Add or Edit Menu Item
app.post('/api/admin/menu', requireAdmin, (req: Request, res: Response) => {
  const { id, category, name, items, timing, image } = req.body;
  const data = db.get();

  if (!category || !name || !items) {
    return res.status(400).json({ error: 'Category, meal name and food items are required' });
  }

  if (id) {
    const idx = data.menus.findIndex((m: any) => m.id === id);
    if (idx >= 0) {
      data.menus[idx] = {
        ...data.menus[idx],
        category,
        name,
        items,
        timing: timing || data.menus[idx].timing,
        image: image || data.menus[idx].image
      };
      db.save();
      return res.json({ success: true, menu: data.menus[idx] });
    }
  }

  const newMenu = {
    id: 'm_' + Date.now(),
    category,
    name,
    items,
    timing: timing || 'Standard Meal Hours',
    image: image || ''
  };

  data.menus.push(newMenu);
  db.save();
  res.json({ success: true, menu: newMenu });
});

// Delete Menu Item
app.delete('/api/admin/menu/:id', requireAdmin, (req: Request, res: Response) => {
  const { id } = req.params;
  const data = db.get();
  data.menus = data.menus.filter((m: any) => m.id !== id);
  db.save();
  res.json({ success: true, message: 'Menu item removed' });
});

// Add or Edit Cook Staff
app.post('/api/admin/staff', requireAdmin, (req: Request, res: Response) => {
  const { id, name, role, shift } = req.body;
  const data = db.get();

  if (!name || !role) {
    return res.status(400).json({ error: 'Staff name and role are required' });
  }

  if (id) {
    const idx = data.staff.findIndex((s: any) => s.id === id);
    if (idx >= 0) {
      data.staff[idx] = { ...data.staff[idx], name, role, shift: shift || 'All Shifts' };
      db.save();
      return res.json({ success: true, staff: data.staff[idx] });
    }
  }

  const newStaff = {
    id: 'cs_' + Date.now(),
    name,
    role,
    shift: shift || 'All Shifts'
  };

  data.staff.push(newStaff);
  db.save();
  res.json({ success: true, staff: newStaff });
});

// Delete Cook Staff
app.delete('/api/admin/staff/:id', requireAdmin, (req: Request, res: Response) => {
  const { id } = req.params;
  const data = db.get();
  data.staff = data.staff.filter((s: any) => s.id !== id);
  db.save();
  res.json({ success: true, message: 'Cook staff removed' });
});

// ==========================================
// WEBSITE CUSTOMIZATION & THEMES
// ==========================================

// Save Custom Website Settings
app.post('/api/admin/settings', requireAdmin, (req: Request, res: Response) => {
  const { settings } = req.body;
  if (!settings) {
    return res.status(400).json({ error: 'Settings object required' });
  }

  const data = db.get();
  data.settings = { ...data.settings, ...settings };
  db.save();

  res.json({ success: true, settings: data.settings });
});

// Reset Settings to Default
app.post('/api/admin/settings/reset', requireAdmin, (req: Request, res: Response) => {
  const initial = getInitialData();
  const data = db.get();
  data.settings = initial.settings;
  db.save();

  res.json({ success: true, settings: data.settings });
});

// Add / Edit Website Announcements
app.post('/api/admin/updates', requireAdmin, (req: Request, res: Response) => {
  const { id, version, title, description, isAnnouncement, isMaintenance, active } = req.body;
  const data = db.get();

  if (id) {
    const idx = data.updates.findIndex((u: any) => u.id === id);
    if (idx >= 0) {
      data.updates[idx] = {
        ...data.updates[idx],
        version,
        title,
        description,
        isAnnouncement: Boolean(isAnnouncement),
        isMaintenance: Boolean(isMaintenance),
        active: active !== undefined ? Boolean(active) : true
      };
      db.save();
      return res.json({ success: true, update: data.updates[idx] });
    }
  }

  const newUpdate = {
    id: 'up_' + Date.now(),
    version: version || 'v1.0.0',
    title,
    description,
    isAnnouncement: Boolean(isAnnouncement),
    isMaintenance: Boolean(isMaintenance),
    active: active !== undefined ? Boolean(active) : true,
    date: new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' })
  };

  data.updates.unshift(newUpdate);
  db.save();
  res.json({ success: true, update: newUpdate });
});

// Delete Website Update
app.delete('/api/admin/updates/:id', requireAdmin, (req: Request, res: Response) => {
  const { id } = req.params;
  const data = db.get();
  data.updates = data.updates.filter((u: any) => u.id !== id);
  db.save();
  res.json({ success: true, message: 'Update removed' });
});

// Backup / Export Entire Database
app.get('/api/admin/backup', requireAdmin, (req: Request, res: Response) => {
  const data = db.get();
  // Safe export omitting sensitive salts
  const exportPayload = {
    ...data,
    exportedAt: new Date().toISOString()
  };
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Content-Disposition', 'attachment; filename="help_anonymous_backup.json"');
  res.send(JSON.stringify(exportPayload, null, 2));
});

// Scheduled background cron job for automatic weekly report reminder
setInterval(() => {
  try {
    const data = db.get();
    if (!data.reminderSettings || !data.reminderSettings.reminderEnabled) return;

    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const now = new Date();
    const currentDay = days[now.getDay()];
    const currentHourMin = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    if (currentDay === data.reminderSettings.reportDay && currentHourMin === data.reminderSettings.reminderTime) {
      const todayDate = now.toISOString().split('T')[0];
      if (data.reminderSettings.lastTriggeredDate !== todayDate) {
        data.reminderSettings.lastTriggeredDate = todayDate;
        data.reminderSettings.lastTriggeredAlert = now.toISOString();
        db.save();
        console.log(`[SCHEDULED AUTOMATION] Automatic Weekly Mess Report generated for Warden (${data.reminderSettings.emailNotification}). Message: "Your weekly Hostel Mess Feedback Report is ready. Please review the latest student feedback and pending complaints."`);
      }
    }
  } catch (err) {
    console.error('Error in scheduled reminder job:', err);
  }
}, 60000);

// ==========================================
// VITE DEV SERVER OR STATIC PRODUCTION SERVE
// ==========================================
async function startServer() {
  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running at http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
